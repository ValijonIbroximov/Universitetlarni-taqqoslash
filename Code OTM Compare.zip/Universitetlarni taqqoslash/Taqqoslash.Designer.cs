﻿namespace Universitetlarni_taqqoslash
{
    partial class Taqqoslash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Taqqoslash));
            this.panelTop = new System.Windows.Forms.Panel();
            this.resultr = new System.Windows.Forms.Label();
            this.resultl = new System.Windows.Forms.Label();
            this.panelVS = new System.Windows.Forms.Panel();
            this.panelOTMData = new System.Windows.Forms.Panel();
            this.z39 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.z38 = new System.Windows.Forms.Panel();
            this.z38r = new System.Windows.Forms.Label();
            this.z38l = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.z37 = new System.Windows.Forms.Panel();
            this.z37r = new System.Windows.Forms.Label();
            this.z37l = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.z36 = new System.Windows.Forms.Panel();
            this.z36r = new System.Windows.Forms.Label();
            this.z36l = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.z35 = new System.Windows.Forms.Panel();
            this.z35r = new System.Windows.Forms.Label();
            this.z35l = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.z34 = new System.Windows.Forms.Panel();
            this.z34r = new System.Windows.Forms.Label();
            this.z34l = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.z33 = new System.Windows.Forms.Panel();
            this.z33r = new System.Windows.Forms.Label();
            this.z33l = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.z32 = new System.Windows.Forms.Panel();
            this.z32r = new System.Windows.Forms.Label();
            this.z32l = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.z31 = new System.Windows.Forms.Panel();
            this.z31r = new System.Windows.Forms.Label();
            this.z31l = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.z30 = new System.Windows.Forms.Panel();
            this.z30r = new System.Windows.Forms.Label();
            this.z30l = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.z29 = new System.Windows.Forms.Panel();
            this.z29r = new System.Windows.Forms.Label();
            this.z29l = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.z28 = new System.Windows.Forms.Panel();
            this.z28r = new System.Windows.Forms.Label();
            this.z28l = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.z27 = new System.Windows.Forms.Panel();
            this.z27r = new System.Windows.Forms.Label();
            this.z27l = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.z26 = new System.Windows.Forms.Panel();
            this.z26r = new System.Windows.Forms.Label();
            this.z26l = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.z25 = new System.Windows.Forms.Panel();
            this.z25r = new System.Windows.Forms.Label();
            this.z25l = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.z24 = new System.Windows.Forms.Panel();
            this.z24r = new System.Windows.Forms.Label();
            this.z24l = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.z23 = new System.Windows.Forms.Panel();
            this.z23r = new System.Windows.Forms.Label();
            this.z23l = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.z22 = new System.Windows.Forms.Panel();
            this.z22r = new System.Windows.Forms.Label();
            this.z22l = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.z21 = new System.Windows.Forms.Panel();
            this.z21r = new System.Windows.Forms.Label();
            this.z21l = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.z20 = new System.Windows.Forms.Panel();
            this.z20r = new System.Windows.Forms.Label();
            this.z20l = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.z19 = new System.Windows.Forms.Panel();
            this.z19r = new System.Windows.Forms.Label();
            this.z19l = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.z18 = new System.Windows.Forms.Panel();
            this.z18r = new System.Windows.Forms.Label();
            this.z18l = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.z17 = new System.Windows.Forms.Panel();
            this.z17r = new System.Windows.Forms.Label();
            this.z17l = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.z16 = new System.Windows.Forms.Panel();
            this.z16r = new System.Windows.Forms.Label();
            this.z16l = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.z15 = new System.Windows.Forms.Panel();
            this.z15r = new System.Windows.Forms.Label();
            this.z15l = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.z14 = new System.Windows.Forms.Panel();
            this.z14r = new System.Windows.Forms.Label();
            this.z14l = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.z13 = new System.Windows.Forms.Panel();
            this.z13r = new System.Windows.Forms.Label();
            this.z13l = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.z12 = new System.Windows.Forms.Panel();
            this.z12r = new System.Windows.Forms.Label();
            this.z12l = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.z11 = new System.Windows.Forms.Panel();
            this.z11r = new System.Windows.Forms.Label();
            this.z11l = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.z10 = new System.Windows.Forms.Panel();
            this.z10r = new System.Windows.Forms.Label();
            this.z10l = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.z9 = new System.Windows.Forms.Panel();
            this.z9r = new System.Windows.Forms.Label();
            this.z9l = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.z8 = new System.Windows.Forms.Panel();
            this.z8r = new System.Windows.Forms.Label();
            this.z8l = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.z7 = new System.Windows.Forms.Panel();
            this.z7r = new System.Windows.Forms.Label();
            this.z7l = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.z6 = new System.Windows.Forms.Panel();
            this.z6r = new System.Windows.Forms.Label();
            this.z6l = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.z5 = new System.Windows.Forms.Panel();
            this.z5r = new System.Windows.Forms.Label();
            this.z5l = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.z4 = new System.Windows.Forms.Panel();
            this.z4r = new System.Windows.Forms.Label();
            this.z4l = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.z3 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.z2 = new System.Windows.Forms.Panel();
            this.z2r = new System.Windows.Forms.Label();
            this.z2l = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.z1 = new System.Windows.Forms.Panel();
            this.z1r = new System.Windows.Forms.Label();
            this.z1l = new System.Windows.Forms.Label();
            this.zId = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.z39l = new System.Windows.Forms.ListBox();
            this.z39r = new System.Windows.Forms.ListBox();
            this.z3l = new System.Windows.Forms.PictureBox();
            this.z3r = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelTop = new System.Windows.Forms.Label();
            this.panelTop.SuspendLayout();
            this.panelVS.SuspendLayout();
            this.panelOTMData.SuspendLayout();
            this.z39.SuspendLayout();
            this.z38.SuspendLayout();
            this.z37.SuspendLayout();
            this.z36.SuspendLayout();
            this.z35.SuspendLayout();
            this.z34.SuspendLayout();
            this.z33.SuspendLayout();
            this.z32.SuspendLayout();
            this.z31.SuspendLayout();
            this.z30.SuspendLayout();
            this.z29.SuspendLayout();
            this.z28.SuspendLayout();
            this.z27.SuspendLayout();
            this.z26.SuspendLayout();
            this.z25.SuspendLayout();
            this.z24.SuspendLayout();
            this.z23.SuspendLayout();
            this.z22.SuspendLayout();
            this.z21.SuspendLayout();
            this.z20.SuspendLayout();
            this.z19.SuspendLayout();
            this.z18.SuspendLayout();
            this.z17.SuspendLayout();
            this.z16.SuspendLayout();
            this.z15.SuspendLayout();
            this.z14.SuspendLayout();
            this.z13.SuspendLayout();
            this.z12.SuspendLayout();
            this.z11.SuspendLayout();
            this.z10.SuspendLayout();
            this.z9.SuspendLayout();
            this.z8.SuspendLayout();
            this.z7.SuspendLayout();
            this.z6.SuspendLayout();
            this.z5.SuspendLayout();
            this.z4.SuspendLayout();
            this.z3.SuspendLayout();
            this.z2.SuspendLayout();
            this.z1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.z3l)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.z3r)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelTop.Controls.Add(this.resultr);
            this.panelTop.Controls.Add(this.resultl);
            this.panelTop.Controls.Add(this.labelTop);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1088, 100);
            this.panelTop.TabIndex = 0;
            // 
            // resultr
            // 
            this.resultr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.resultr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resultr.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.resultr.Location = new System.Drawing.Point(554, 30);
            this.resultr.Name = "resultr";
            this.resultr.Size = new System.Drawing.Size(534, 70);
            this.resultr.TabIndex = 1;
            this.resultr.Text = "0";
            this.resultr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // resultl
            // 
            this.resultl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.resultl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultl.Dock = System.Windows.Forms.DockStyle.Left;
            this.resultl.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.resultl.Location = new System.Drawing.Point(0, 30);
            this.resultl.Name = "resultl";
            this.resultl.Size = new System.Drawing.Size(554, 70);
            this.resultl.TabIndex = 0;
            this.resultl.Text = "0";
            this.resultl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelVS
            // 
            this.panelVS.AutoScroll = true;
            this.panelVS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelVS.Controls.Add(this.panelOTMData);
            this.panelVS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelVS.Location = new System.Drawing.Point(0, 100);
            this.panelVS.Name = "panelVS";
            this.panelVS.Size = new System.Drawing.Size(1088, 467);
            this.panelVS.TabIndex = 1;
            // 
            // panelOTMData
            // 
            this.panelOTMData.AutoScroll = true;
            this.panelOTMData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelOTMData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelOTMData.Controls.Add(this.z39);
            this.panelOTMData.Controls.Add(this.label37);
            this.panelOTMData.Controls.Add(this.z38);
            this.panelOTMData.Controls.Add(this.label36);
            this.panelOTMData.Controls.Add(this.label125);
            this.panelOTMData.Controls.Add(this.z37);
            this.panelOTMData.Controls.Add(this.label35);
            this.panelOTMData.Controls.Add(this.z36);
            this.panelOTMData.Controls.Add(this.label34);
            this.panelOTMData.Controls.Add(this.z35);
            this.panelOTMData.Controls.Add(this.label33);
            this.panelOTMData.Controls.Add(this.label124);
            this.panelOTMData.Controls.Add(this.z34);
            this.panelOTMData.Controls.Add(this.label32);
            this.panelOTMData.Controls.Add(this.z33);
            this.panelOTMData.Controls.Add(this.label31);
            this.panelOTMData.Controls.Add(this.z32);
            this.panelOTMData.Controls.Add(this.label30);
            this.panelOTMData.Controls.Add(this.label123);
            this.panelOTMData.Controls.Add(this.z31);
            this.panelOTMData.Controls.Add(this.label29);
            this.panelOTMData.Controls.Add(this.z30);
            this.panelOTMData.Controls.Add(this.label28);
            this.panelOTMData.Controls.Add(this.z29);
            this.panelOTMData.Controls.Add(this.label27);
            this.panelOTMData.Controls.Add(this.label122);
            this.panelOTMData.Controls.Add(this.z28);
            this.panelOTMData.Controls.Add(this.label26);
            this.panelOTMData.Controls.Add(this.z27);
            this.panelOTMData.Controls.Add(this.label25);
            this.panelOTMData.Controls.Add(this.z26);
            this.panelOTMData.Controls.Add(this.label24);
            this.panelOTMData.Controls.Add(this.z25);
            this.panelOTMData.Controls.Add(this.label23);
            this.panelOTMData.Controls.Add(this.z24);
            this.panelOTMData.Controls.Add(this.label22);
            this.panelOTMData.Controls.Add(this.z23);
            this.panelOTMData.Controls.Add(this.label21);
            this.panelOTMData.Controls.Add(this.z22);
            this.panelOTMData.Controls.Add(this.label20);
            this.panelOTMData.Controls.Add(this.z21);
            this.panelOTMData.Controls.Add(this.label19);
            this.panelOTMData.Controls.Add(this.z20);
            this.panelOTMData.Controls.Add(this.label18);
            this.panelOTMData.Controls.Add(this.label121);
            this.panelOTMData.Controls.Add(this.z19);
            this.panelOTMData.Controls.Add(this.label17);
            this.panelOTMData.Controls.Add(this.z18);
            this.panelOTMData.Controls.Add(this.label38);
            this.panelOTMData.Controls.Add(this.z17);
            this.panelOTMData.Controls.Add(this.label16);
            this.panelOTMData.Controls.Add(this.z16);
            this.panelOTMData.Controls.Add(this.label15);
            this.panelOTMData.Controls.Add(this.z15);
            this.panelOTMData.Controls.Add(this.label14);
            this.panelOTMData.Controls.Add(this.z14);
            this.panelOTMData.Controls.Add(this.label13);
            this.panelOTMData.Controls.Add(this.z13);
            this.panelOTMData.Controls.Add(this.label12);
            this.panelOTMData.Controls.Add(this.z12);
            this.panelOTMData.Controls.Add(this.label11);
            this.panelOTMData.Controls.Add(this.z11);
            this.panelOTMData.Controls.Add(this.label10);
            this.panelOTMData.Controls.Add(this.label120);
            this.panelOTMData.Controls.Add(this.z10);
            this.panelOTMData.Controls.Add(this.label9);
            this.panelOTMData.Controls.Add(this.z9);
            this.panelOTMData.Controls.Add(this.label8);
            this.panelOTMData.Controls.Add(this.z8);
            this.panelOTMData.Controls.Add(this.label7);
            this.panelOTMData.Controls.Add(this.z7);
            this.panelOTMData.Controls.Add(this.label6);
            this.panelOTMData.Controls.Add(this.z6);
            this.panelOTMData.Controls.Add(this.label5);
            this.panelOTMData.Controls.Add(this.z5);
            this.panelOTMData.Controls.Add(this.label4);
            this.panelOTMData.Controls.Add(this.z4);
            this.panelOTMData.Controls.Add(this.label3);
            this.panelOTMData.Controls.Add(this.z3);
            this.panelOTMData.Controls.Add(this.label39);
            this.panelOTMData.Controls.Add(this.z2);
            this.panelOTMData.Controls.Add(this.label40);
            this.panelOTMData.Controls.Add(this.z1);
            this.panelOTMData.Controls.Add(this.zId);
            this.panelOTMData.Controls.Add(this.label119);
            this.panelOTMData.Controls.Add(this.textBox1);
            this.panelOTMData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOTMData.Location = new System.Drawing.Point(0, 0);
            this.panelOTMData.Name = "panelOTMData";
            this.panelOTMData.Size = new System.Drawing.Size(1088, 467);
            this.panelOTMData.TabIndex = 7;
            // 
            // z39
            // 
            this.z39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z39.Controls.Add(this.z39r);
            this.z39.Controls.Add(this.z39l);
            this.z39.Dock = System.Windows.Forms.DockStyle.Top;
            this.z39.Location = new System.Drawing.Point(0, 2514);
            this.z39.Name = "z39";
            this.z39.Size = new System.Drawing.Size(1063, 90);
            this.z39.TabIndex = 120;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Dock = System.Windows.Forms.DockStyle.Top;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(0, 2488);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(1063, 26);
            this.label37.TabIndex = 76;
            this.label37.Text = "Ta\'lim yo\'nalishlari(Mavjud ta\'lim yo\'nalishlar tanlangan holatda)";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z38
            // 
            this.z38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z38.Controls.Add(this.z38r);
            this.z38.Controls.Add(this.z38l);
            this.z38.Dock = System.Windows.Forms.DockStyle.Top;
            this.z38.Location = new System.Drawing.Point(0, 2458);
            this.z38.Name = "z38";
            this.z38.Size = new System.Drawing.Size(1063, 30);
            this.z38.TabIndex = 119;
            // 
            // z38r
            // 
            this.z38r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z38r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z38r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z38r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z38r.Location = new System.Drawing.Point(554, 0);
            this.z38r.Name = "z38r";
            this.z38r.Size = new System.Drawing.Size(509, 30);
            this.z38r.TabIndex = 1;
            this.z38r.Text = "0";
            this.z38r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z38l
            // 
            this.z38l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z38l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z38l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z38l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z38l.Location = new System.Drawing.Point(0, 0);
            this.z38l.Name = "z38l";
            this.z38l.Size = new System.Drawing.Size(554, 30);
            this.z38l.TabIndex = 0;
            this.z38l.Text = "0";
            this.z38l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Dock = System.Windows.Forms.DockStyle.Top;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(0, 2432);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(1063, 26);
            this.label36.TabIndex = 74;
            this.label36.Text = "Fakultetlar soni";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label125
            // 
            this.label125.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label125.Dock = System.Windows.Forms.DockStyle.Top;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label125.Location = new System.Drawing.Point(0, 2402);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(1063, 30);
            this.label125.TabIndex = 127;
            this.label125.Text = "Fakultetlar soni va ta\'lim yo\'nalishlari";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z37
            // 
            this.z37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z37.Controls.Add(this.z37r);
            this.z37.Controls.Add(this.z37l);
            this.z37.Dock = System.Windows.Forms.DockStyle.Top;
            this.z37.Location = new System.Drawing.Point(0, 2372);
            this.z37.Name = "z37";
            this.z37.Size = new System.Drawing.Size(1063, 30);
            this.z37.TabIndex = 118;
            // 
            // z37r
            // 
            this.z37r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z37r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z37r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z37r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z37r.Location = new System.Drawing.Point(554, 0);
            this.z37r.Name = "z37r";
            this.z37r.Size = new System.Drawing.Size(509, 30);
            this.z37r.TabIndex = 1;
            this.z37r.Text = "0";
            this.z37r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z37l
            // 
            this.z37l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z37l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z37l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z37l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z37l.Location = new System.Drawing.Point(0, 0);
            this.z37l.Name = "z37l";
            this.z37l.Size = new System.Drawing.Size(554, 30);
            this.z37l.TabIndex = 0;
            this.z37l.Text = "0";
            this.z37l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Dock = System.Windows.Forms.DockStyle.Top;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(0, 2346);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(1063, 26);
            this.label35.TabIndex = 72;
            this.label35.Text = "Kontrakt asosida o\'qish uchun ajratilgan joylar";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z36
            // 
            this.z36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z36.Controls.Add(this.z36r);
            this.z36.Controls.Add(this.z36l);
            this.z36.Dock = System.Windows.Forms.DockStyle.Top;
            this.z36.Location = new System.Drawing.Point(0, 2316);
            this.z36.Name = "z36";
            this.z36.Size = new System.Drawing.Size(1063, 30);
            this.z36.TabIndex = 117;
            // 
            // z36r
            // 
            this.z36r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z36r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z36r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z36r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z36r.Location = new System.Drawing.Point(554, 0);
            this.z36r.Name = "z36r";
            this.z36r.Size = new System.Drawing.Size(509, 30);
            this.z36r.TabIndex = 1;
            this.z36r.Text = "0";
            this.z36r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z36l
            // 
            this.z36l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z36l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z36l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z36l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z36l.Location = new System.Drawing.Point(0, 0);
            this.z36l.Name = "z36l";
            this.z36l.Size = new System.Drawing.Size(554, 30);
            this.z36l.TabIndex = 0;
            this.z36l.Text = "0";
            this.z36l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Dock = System.Windows.Forms.DockStyle.Top;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(0, 2290);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(1063, 26);
            this.label34.TabIndex = 70;
            this.label34.Text = "Grant asosida o\'qish uchun ajratilgan joylar";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z35
            // 
            this.z35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z35.Controls.Add(this.z35r);
            this.z35.Controls.Add(this.z35l);
            this.z35.Dock = System.Windows.Forms.DockStyle.Top;
            this.z35.Location = new System.Drawing.Point(0, 2260);
            this.z35.Name = "z35";
            this.z35.Size = new System.Drawing.Size(1063, 30);
            this.z35.TabIndex = 116;
            // 
            // z35r
            // 
            this.z35r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z35r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z35r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z35r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z35r.Location = new System.Drawing.Point(554, 0);
            this.z35r.Name = "z35r";
            this.z35r.Size = new System.Drawing.Size(509, 30);
            this.z35r.TabIndex = 1;
            this.z35r.Text = "0";
            this.z35r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z35l
            // 
            this.z35l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z35l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z35l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z35l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z35l.Location = new System.Drawing.Point(0, 0);
            this.z35l.Name = "z35l";
            this.z35l.Size = new System.Drawing.Size(554, 30);
            this.z35l.TabIndex = 0;
            this.z35l.Text = "0";
            this.z35l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Dock = System.Windows.Forms.DockStyle.Top;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(0, 2234);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(1063, 26);
            this.label33.TabIndex = 68;
            this.label33.Text = "Qabul uchun ajratilgan joylar(kvotalar)";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label124
            // 
            this.label124.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label124.Dock = System.Windows.Forms.DockStyle.Top;
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label124.Location = new System.Drawing.Point(0, 2204);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(1063, 30);
            this.label124.TabIndex = 126;
            this.label124.Text = "Qabul uchun ajratilgan joylar";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z34
            // 
            this.z34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z34.Controls.Add(this.z34r);
            this.z34.Controls.Add(this.z34l);
            this.z34.Dock = System.Windows.Forms.DockStyle.Top;
            this.z34.Location = new System.Drawing.Point(0, 2174);
            this.z34.Name = "z34";
            this.z34.Size = new System.Drawing.Size(1063, 30);
            this.z34.TabIndex = 115;
            // 
            // z34r
            // 
            this.z34r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z34r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z34r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z34r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z34r.Location = new System.Drawing.Point(554, 0);
            this.z34r.Name = "z34r";
            this.z34r.Size = new System.Drawing.Size(509, 30);
            this.z34r.TabIndex = 1;
            this.z34r.Text = "0";
            this.z34r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z34l
            // 
            this.z34l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z34l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z34l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z34l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z34l.Location = new System.Drawing.Point(0, 0);
            this.z34l.Name = "z34l";
            this.z34l.Size = new System.Drawing.Size(554, 30);
            this.z34l.TabIndex = 0;
            this.z34l.Text = "0";
            this.z34l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Dock = System.Windows.Forms.DockStyle.Top;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(0, 2148);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(1063, 26);
            this.label32.TabIndex = 66;
            this.label32.Text = "Yotoqxona to\'lovi";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z33
            // 
            this.z33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z33.Controls.Add(this.z33r);
            this.z33.Controls.Add(this.z33l);
            this.z33.Dock = System.Windows.Forms.DockStyle.Top;
            this.z33.Location = new System.Drawing.Point(0, 2118);
            this.z33.Name = "z33";
            this.z33.Size = new System.Drawing.Size(1063, 30);
            this.z33.TabIndex = 114;
            // 
            // z33r
            // 
            this.z33r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z33r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z33r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z33r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z33r.Location = new System.Drawing.Point(554, 0);
            this.z33r.Name = "z33r";
            this.z33r.Size = new System.Drawing.Size(509, 30);
            this.z33r.TabIndex = 1;
            this.z33r.Text = "0";
            this.z33r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z33l
            // 
            this.z33l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z33l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z33l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z33l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z33l.Location = new System.Drawing.Point(0, 0);
            this.z33l.Name = "z33l";
            this.z33l.Size = new System.Drawing.Size(554, 30);
            this.z33l.TabIndex = 0;
            this.z33l.Text = "0";
            this.z33l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Dock = System.Windows.Forms.DockStyle.Top;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(0, 2092);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(1063, 26);
            this.label31.TabIndex = 64;
            this.label31.Text = "Kontrakt to\'lovi(o\'rtacha)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z32
            // 
            this.z32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z32.Controls.Add(this.z32r);
            this.z32.Controls.Add(this.z32l);
            this.z32.Dock = System.Windows.Forms.DockStyle.Top;
            this.z32.Location = new System.Drawing.Point(0, 2062);
            this.z32.Name = "z32";
            this.z32.Size = new System.Drawing.Size(1063, 30);
            this.z32.TabIndex = 113;
            // 
            // z32r
            // 
            this.z32r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z32r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z32r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z32r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z32r.Location = new System.Drawing.Point(554, 0);
            this.z32r.Name = "z32r";
            this.z32r.Size = new System.Drawing.Size(509, 30);
            this.z32r.TabIndex = 1;
            this.z32r.Text = "0";
            this.z32r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z32l
            // 
            this.z32l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z32l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z32l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z32l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z32l.Location = new System.Drawing.Point(0, 0);
            this.z32l.Name = "z32l";
            this.z32l.Size = new System.Drawing.Size(554, 30);
            this.z32l.TabIndex = 0;
            this.z32l.Text = "0";
            this.z32l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Dock = System.Windows.Forms.DockStyle.Top;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(0, 2036);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(1063, 26);
            this.label30.TabIndex = 62;
            this.label30.Text = "Stipendiya(o\'rtacha)";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label123
            // 
            this.label123.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label123.Dock = System.Windows.Forms.DockStyle.Top;
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label123.Location = new System.Drawing.Point(0, 2006);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(1063, 30);
            this.label123.TabIndex = 125;
            this.label123.Text = "To\'lovlar";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z31
            // 
            this.z31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z31.Controls.Add(this.z31r);
            this.z31.Controls.Add(this.z31l);
            this.z31.Dock = System.Windows.Forms.DockStyle.Top;
            this.z31.Location = new System.Drawing.Point(0, 1976);
            this.z31.Name = "z31";
            this.z31.Size = new System.Drawing.Size(1063, 30);
            this.z31.TabIndex = 112;
            // 
            // z31r
            // 
            this.z31r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z31r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z31r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z31r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z31r.Location = new System.Drawing.Point(554, 0);
            this.z31r.Name = "z31r";
            this.z31r.Size = new System.Drawing.Size(509, 30);
            this.z31r.TabIndex = 1;
            this.z31r.Text = "0";
            this.z31r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z31l
            // 
            this.z31l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z31l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z31l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z31l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z31l.Location = new System.Drawing.Point(0, 0);
            this.z31l.Name = "z31l";
            this.z31l.Size = new System.Drawing.Size(554, 30);
            this.z31l.TabIndex = 0;
            this.z31l.Text = "0";
            this.z31l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Dock = System.Windows.Forms.DockStyle.Top;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(0, 1950);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(1063, 26);
            this.label29.TabIndex = 60;
            this.label29.Text = "Yotoqxona sig\'imi(necha kishi sig\'a olishi)";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z30
            // 
            this.z30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z30.Controls.Add(this.z30r);
            this.z30.Controls.Add(this.z30l);
            this.z30.Dock = System.Windows.Forms.DockStyle.Top;
            this.z30.Location = new System.Drawing.Point(0, 1920);
            this.z30.Name = "z30";
            this.z30.Size = new System.Drawing.Size(1063, 30);
            this.z30.TabIndex = 111;
            // 
            // z30r
            // 
            this.z30r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z30r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z30r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z30r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z30r.Location = new System.Drawing.Point(554, 0);
            this.z30r.Name = "z30r";
            this.z30r.Size = new System.Drawing.Size(509, 30);
            this.z30r.TabIndex = 1;
            this.z30r.Text = "0";
            this.z30r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z30l
            // 
            this.z30l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z30l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z30l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z30l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z30l.Location = new System.Drawing.Point(0, 0);
            this.z30l.Name = "z30l";
            this.z30l.Size = new System.Drawing.Size(554, 30);
            this.z30l.TabIndex = 0;
            this.z30l.Text = "0";
            this.z30l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Dock = System.Windows.Forms.DockStyle.Top;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(0, 1894);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(1063, 26);
            this.label28.TabIndex = 58;
            this.label28.Text = "Oliy o\'quv yurti binosining sig\'imi(necha kishi sig\'a olishi)";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z29
            // 
            this.z29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z29.Controls.Add(this.z29r);
            this.z29.Controls.Add(this.z29l);
            this.z29.Dock = System.Windows.Forms.DockStyle.Top;
            this.z29.Location = new System.Drawing.Point(0, 1864);
            this.z29.Name = "z29";
            this.z29.Size = new System.Drawing.Size(1063, 30);
            this.z29.TabIndex = 110;
            // 
            // z29r
            // 
            this.z29r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z29r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z29r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z29r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z29r.Location = new System.Drawing.Point(554, 0);
            this.z29r.Name = "z29r";
            this.z29r.Size = new System.Drawing.Size(509, 30);
            this.z29r.TabIndex = 1;
            this.z29r.Text = "0";
            this.z29r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z29l
            // 
            this.z29l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z29l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z29l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z29l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z29l.Location = new System.Drawing.Point(0, 0);
            this.z29l.Name = "z29l";
            this.z29l.Size = new System.Drawing.Size(554, 30);
            this.z29l.TabIndex = 0;
            this.z29l.Text = "0";
            this.z29l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(0, 1838);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(1063, 26);
            this.label27.TabIndex = 56;
            this.label27.Text = "Axborot resurslari soni";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label122
            // 
            this.label122.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label122.Dock = System.Windows.Forms.DockStyle.Top;
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label122.Location = new System.Drawing.Point(0, 1808);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(1063, 30);
            this.label122.TabIndex = 124;
            this.label122.Text = "Axborot resurslari va bino sig\'imlari";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z28
            // 
            this.z28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z28.Controls.Add(this.z28r);
            this.z28.Controls.Add(this.z28l);
            this.z28.Dock = System.Windows.Forms.DockStyle.Top;
            this.z28.Location = new System.Drawing.Point(0, 1778);
            this.z28.Name = "z28";
            this.z28.Size = new System.Drawing.Size(1063, 30);
            this.z28.TabIndex = 109;
            // 
            // z28r
            // 
            this.z28r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z28r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z28r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z28r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z28r.Location = new System.Drawing.Point(554, 0);
            this.z28r.Name = "z28r";
            this.z28r.Size = new System.Drawing.Size(509, 30);
            this.z28r.TabIndex = 1;
            this.z28r.Text = "0";
            this.z28r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z28l
            // 
            this.z28l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z28l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z28l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z28l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z28l.Location = new System.Drawing.Point(0, 0);
            this.z28l.Name = "z28l";
            this.z28l.Size = new System.Drawing.Size(554, 30);
            this.z28l.TabIndex = 0;
            this.z28l.Text = "0";
            this.z28l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Dock = System.Windows.Forms.DockStyle.Top;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(0, 1752);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(1063, 26);
            this.label26.TabIndex = 54;
            this.label26.Text = "Talabalarning o\'rtacha GPA bali";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z27
            // 
            this.z27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z27.Controls.Add(this.z27r);
            this.z27.Controls.Add(this.z27l);
            this.z27.Dock = System.Windows.Forms.DockStyle.Top;
            this.z27.Location = new System.Drawing.Point(0, 1722);
            this.z27.Name = "z27";
            this.z27.Size = new System.Drawing.Size(1063, 30);
            this.z27.TabIndex = 108;
            // 
            // z27r
            // 
            this.z27r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z27r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z27r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z27r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z27r.Location = new System.Drawing.Point(554, 0);
            this.z27r.Name = "z27r";
            this.z27r.Size = new System.Drawing.Size(509, 30);
            this.z27r.TabIndex = 1;
            this.z27r.Text = "0";
            this.z27r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z27l
            // 
            this.z27l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z27l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z27l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z27l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z27l.Location = new System.Drawing.Point(0, 0);
            this.z27l.Name = "z27l";
            this.z27l.Size = new System.Drawing.Size(554, 30);
            this.z27l.TabIndex = 0;
            this.z27l.Text = "0";
            this.z27l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Dock = System.Windows.Forms.DockStyle.Top;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(0, 1696);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(1063, 26);
            this.label25.TabIndex = 52;
            this.label25.Text = "Qarzdor talabalarning umumiy qarzi(so\'m valyutasida)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z26
            // 
            this.z26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z26.Controls.Add(this.z26r);
            this.z26.Controls.Add(this.z26l);
            this.z26.Dock = System.Windows.Forms.DockStyle.Top;
            this.z26.Location = new System.Drawing.Point(0, 1666);
            this.z26.Name = "z26";
            this.z26.Size = new System.Drawing.Size(1063, 30);
            this.z26.TabIndex = 107;
            // 
            // z26r
            // 
            this.z26r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z26r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z26r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z26r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z26r.Location = new System.Drawing.Point(554, 0);
            this.z26r.Name = "z26r";
            this.z26r.Size = new System.Drawing.Size(509, 30);
            this.z26r.TabIndex = 1;
            this.z26r.Text = "0";
            this.z26r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z26l
            // 
            this.z26l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z26l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z26l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z26l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z26l.Location = new System.Drawing.Point(0, 0);
            this.z26l.Name = "z26l";
            this.z26l.Size = new System.Drawing.Size(554, 30);
            this.z26l.TabIndex = 0;
            this.z26l.Text = "0";
            this.z26l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Dock = System.Windows.Forms.DockStyle.Top;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(0, 1640);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(1063, 26);
            this.label24.TabIndex = 50;
            this.label24.Text = "Qarzdor talabalar soni";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z25
            // 
            this.z25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z25.Controls.Add(this.z25r);
            this.z25.Controls.Add(this.z25l);
            this.z25.Dock = System.Windows.Forms.DockStyle.Top;
            this.z25.Location = new System.Drawing.Point(0, 1610);
            this.z25.Name = "z25";
            this.z25.Size = new System.Drawing.Size(1063, 30);
            this.z25.TabIndex = 106;
            // 
            // z25r
            // 
            this.z25r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z25r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z25r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z25r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z25r.Location = new System.Drawing.Point(554, 0);
            this.z25r.Name = "z25r";
            this.z25r.Size = new System.Drawing.Size(509, 30);
            this.z25r.TabIndex = 1;
            this.z25r.Text = "0";
            this.z25r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z25l
            // 
            this.z25l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z25l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z25l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z25l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z25l.Location = new System.Drawing.Point(0, 0);
            this.z25l.Name = "z25l";
            this.z25l.Size = new System.Drawing.Size(554, 30);
            this.z25l.TabIndex = 0;
            this.z25l.Text = "0";
            this.z25l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Dock = System.Windows.Forms.DockStyle.Top;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(0, 1584);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(1063, 26);
            this.label23.TabIndex = 48;
            this.label23.Text = "Bitirgan talabalarning o\'z sohasida ish bilan bandligi(foiz ko\'rsatkichida)";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z24
            // 
            this.z24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z24.Controls.Add(this.z24r);
            this.z24.Controls.Add(this.z24l);
            this.z24.Dock = System.Windows.Forms.DockStyle.Top;
            this.z24.Location = new System.Drawing.Point(0, 1554);
            this.z24.Name = "z24";
            this.z24.Size = new System.Drawing.Size(1063, 30);
            this.z24.TabIndex = 105;
            // 
            // z24r
            // 
            this.z24r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z24r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z24r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z24r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z24r.Location = new System.Drawing.Point(554, 0);
            this.z24r.Name = "z24r";
            this.z24r.Size = new System.Drawing.Size(509, 30);
            this.z24r.TabIndex = 1;
            this.z24r.Text = "0";
            this.z24r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z24l
            // 
            this.z24l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z24l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z24l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z24l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z24l.Location = new System.Drawing.Point(0, 0);
            this.z24l.Name = "z24l";
            this.z24l.Size = new System.Drawing.Size(554, 30);
            this.z24l.TabIndex = 0;
            this.z24l.Text = "0";
            this.z24l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Dock = System.Windows.Forms.DockStyle.Top;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(0, 1528);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(1063, 26);
            this.label22.TabIndex = 46;
            this.label22.Text = "Bitiruvchi talabalar soni";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z23
            // 
            this.z23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z23.Controls.Add(this.z23r);
            this.z23.Controls.Add(this.z23l);
            this.z23.Dock = System.Windows.Forms.DockStyle.Top;
            this.z23.Location = new System.Drawing.Point(0, 1498);
            this.z23.Name = "z23";
            this.z23.Size = new System.Drawing.Size(1063, 30);
            this.z23.TabIndex = 104;
            // 
            // z23r
            // 
            this.z23r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z23r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z23r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z23r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z23r.Location = new System.Drawing.Point(554, 0);
            this.z23r.Name = "z23r";
            this.z23r.Size = new System.Drawing.Size(509, 30);
            this.z23r.TabIndex = 1;
            this.z23r.Text = "0";
            this.z23r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z23l
            // 
            this.z23l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z23l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z23l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z23l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z23l.Location = new System.Drawing.Point(0, 0);
            this.z23l.Name = "z23l";
            this.z23l.Size = new System.Drawing.Size(554, 30);
            this.z23l.TabIndex = 0;
            this.z23l.Text = "0";
            this.z23l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Dock = System.Windows.Forms.DockStyle.Top;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(0, 1472);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(1063, 26);
            this.label21.TabIndex = 44;
            this.label21.Text = "Xorijiy davlat fuqarosi bo\'lgan talabalar soni";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z22
            // 
            this.z22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z22.Controls.Add(this.z22r);
            this.z22.Controls.Add(this.z22l);
            this.z22.Dock = System.Windows.Forms.DockStyle.Top;
            this.z22.Location = new System.Drawing.Point(0, 1442);
            this.z22.Name = "z22";
            this.z22.Size = new System.Drawing.Size(1063, 30);
            this.z22.TabIndex = 103;
            // 
            // z22r
            // 
            this.z22r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z22r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z22r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z22r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z22r.Location = new System.Drawing.Point(554, 0);
            this.z22r.Name = "z22r";
            this.z22r.Size = new System.Drawing.Size(509, 30);
            this.z22r.TabIndex = 1;
            this.z22r.Text = "0";
            this.z22r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z22l
            // 
            this.z22l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z22l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z22l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z22l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z22l.Location = new System.Drawing.Point(0, 0);
            this.z22l.Name = "z22l";
            this.z22l.Size = new System.Drawing.Size(554, 30);
            this.z22l.TabIndex = 0;
            this.z22l.Text = "0";
            this.z22l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Dock = System.Windows.Forms.DockStyle.Top;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(0, 1416);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(1063, 26);
            this.label20.TabIndex = 42;
            this.label20.Text = "Ayol talabalar soni";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z21
            // 
            this.z21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z21.Controls.Add(this.z21r);
            this.z21.Controls.Add(this.z21l);
            this.z21.Dock = System.Windows.Forms.DockStyle.Top;
            this.z21.Location = new System.Drawing.Point(0, 1386);
            this.z21.Name = "z21";
            this.z21.Size = new System.Drawing.Size(1063, 30);
            this.z21.TabIndex = 102;
            // 
            // z21r
            // 
            this.z21r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z21r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z21r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z21r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z21r.Location = new System.Drawing.Point(554, 0);
            this.z21r.Name = "z21r";
            this.z21r.Size = new System.Drawing.Size(509, 30);
            this.z21r.TabIndex = 1;
            this.z21r.Text = "0";
            this.z21r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z21l
            // 
            this.z21l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z21l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z21l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z21l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z21l.Location = new System.Drawing.Point(0, 0);
            this.z21l.Name = "z21l";
            this.z21l.Size = new System.Drawing.Size(554, 30);
            this.z21l.TabIndex = 0;
            this.z21l.Text = "0";
            this.z21l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Dock = System.Windows.Forms.DockStyle.Top;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(0, 1360);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(1063, 26);
            this.label19.TabIndex = 40;
            this.label19.Text = "Erkak talabalar soni";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z20
            // 
            this.z20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z20.Controls.Add(this.z20r);
            this.z20.Controls.Add(this.z20l);
            this.z20.Dock = System.Windows.Forms.DockStyle.Top;
            this.z20.Location = new System.Drawing.Point(0, 1330);
            this.z20.Name = "z20";
            this.z20.Size = new System.Drawing.Size(1063, 30);
            this.z20.TabIndex = 101;
            // 
            // z20r
            // 
            this.z20r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z20r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z20r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z20r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z20r.Location = new System.Drawing.Point(554, 0);
            this.z20r.Name = "z20r";
            this.z20r.Size = new System.Drawing.Size(509, 30);
            this.z20r.TabIndex = 1;
            this.z20r.Text = "0";
            this.z20r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z20l
            // 
            this.z20l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z20l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z20l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z20l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z20l.Location = new System.Drawing.Point(0, 0);
            this.z20l.Name = "z20l";
            this.z20l.Size = new System.Drawing.Size(554, 30);
            this.z20l.TabIndex = 0;
            this.z20l.Text = "0";
            this.z20l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Dock = System.Windows.Forms.DockStyle.Top;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(0, 1304);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(1063, 26);
            this.label18.TabIndex = 38;
            this.label18.Text = "Talabalar soni";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label121
            // 
            this.label121.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label121.Dock = System.Windows.Forms.DockStyle.Top;
            this.label121.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label121.Location = new System.Drawing.Point(0, 1274);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(1063, 30);
            this.label121.TabIndex = 123;
            this.label121.Text = "Talabalar";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z19
            // 
            this.z19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z19.Controls.Add(this.z19r);
            this.z19.Controls.Add(this.z19l);
            this.z19.Dock = System.Windows.Forms.DockStyle.Top;
            this.z19.Location = new System.Drawing.Point(0, 1244);
            this.z19.Name = "z19";
            this.z19.Size = new System.Drawing.Size(1063, 30);
            this.z19.TabIndex = 100;
            // 
            // z19r
            // 
            this.z19r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z19r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z19r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z19r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z19r.Location = new System.Drawing.Point(554, 0);
            this.z19r.Name = "z19r";
            this.z19r.Size = new System.Drawing.Size(509, 30);
            this.z19r.TabIndex = 1;
            this.z19r.Text = "0";
            this.z19r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z19l
            // 
            this.z19l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z19l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z19l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z19l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z19l.Location = new System.Drawing.Point(0, 0);
            this.z19l.Name = "z19l";
            this.z19l.Size = new System.Drawing.Size(554, 30);
            this.z19l.TabIndex = 0;
            this.z19l.Text = "0";
            this.z19l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(0, 1218);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(1063, 26);
            this.label17.TabIndex = 36;
            this.label17.Text = "Professor-oʻqituvchilarning o\'rtacha KPI bali";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z18
            // 
            this.z18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z18.Controls.Add(this.z18r);
            this.z18.Controls.Add(this.z18l);
            this.z18.Dock = System.Windows.Forms.DockStyle.Top;
            this.z18.Location = new System.Drawing.Point(0, 1188);
            this.z18.Name = "z18";
            this.z18.Size = new System.Drawing.Size(1063, 30);
            this.z18.TabIndex = 99;
            // 
            // z18r
            // 
            this.z18r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z18r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z18r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z18r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z18r.Location = new System.Drawing.Point(554, 0);
            this.z18r.Name = "z18r";
            this.z18r.Size = new System.Drawing.Size(509, 30);
            this.z18r.TabIndex = 1;
            this.z18r.Text = "0";
            this.z18r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z18l
            // 
            this.z18l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z18l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z18l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z18l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z18l.Location = new System.Drawing.Point(0, 0);
            this.z18l.Name = "z18l";
            this.z18l.Size = new System.Drawing.Size(554, 30);
            this.z18l.TabIndex = 0;
            this.z18l.Text = "0";
            this.z18l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Dock = System.Windows.Forms.DockStyle.Top;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(0, 1162);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(1063, 26);
            this.label38.TabIndex = 79;
            this.label38.Text = "Ilmiy tadqiqot natijalari asosida olingan mablag\'lari ko\'rsatkichi";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z17
            // 
            this.z17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z17.Controls.Add(this.z17r);
            this.z17.Controls.Add(this.z17l);
            this.z17.Dock = System.Windows.Forms.DockStyle.Top;
            this.z17.Location = new System.Drawing.Point(0, 1132);
            this.z17.Name = "z17";
            this.z17.Size = new System.Drawing.Size(1063, 30);
            this.z17.TabIndex = 98;
            // 
            // z17r
            // 
            this.z17r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z17r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z17r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z17r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z17r.Location = new System.Drawing.Point(554, 0);
            this.z17r.Name = "z17r";
            this.z17r.Size = new System.Drawing.Size(509, 30);
            this.z17r.TabIndex = 1;
            this.z17r.Text = "0";
            this.z17r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z17l
            // 
            this.z17l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z17l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z17l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z17l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z17l.Location = new System.Drawing.Point(0, 0);
            this.z17l.Name = "z17l";
            this.z17l.Size = new System.Drawing.Size(554, 30);
            this.z17l.TabIndex = 0;
            this.z17l.Text = "0";
            this.z17l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(0, 1106);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(1063, 26);
            this.label16.TabIndex = 34;
            this.label16.Text = "Ilmiy maqolalariga iqtiboslar soni(Xalqaro Scopus va Web of Science ma\'lumotlar b" +
    "azasidagi)";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z16
            // 
            this.z16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z16.Controls.Add(this.z16r);
            this.z16.Controls.Add(this.z16l);
            this.z16.Dock = System.Windows.Forms.DockStyle.Top;
            this.z16.Location = new System.Drawing.Point(0, 1076);
            this.z16.Name = "z16";
            this.z16.Size = new System.Drawing.Size(1063, 30);
            this.z16.TabIndex = 97;
            // 
            // z16r
            // 
            this.z16r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z16r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z16r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z16r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z16r.Location = new System.Drawing.Point(554, 0);
            this.z16r.Name = "z16r";
            this.z16r.Size = new System.Drawing.Size(509, 30);
            this.z16r.TabIndex = 1;
            this.z16r.Text = "0";
            this.z16r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z16l
            // 
            this.z16l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z16l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z16l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z16l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z16l.Location = new System.Drawing.Point(0, 0);
            this.z16l.Name = "z16l";
            this.z16l.Size = new System.Drawing.Size(554, 30);
            this.z16l.TabIndex = 0;
            this.z16l.Text = "0";
            this.z16l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Dock = System.Windows.Forms.DockStyle.Top;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(0, 1050);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(1063, 26);
            this.label15.TabIndex = 32;
            this.label15.Text = "Ilmiy maqolalar soni(Xalqaro Scopus va Web of Science ma\'lumotlar bazasidagi)";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z15
            // 
            this.z15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z15.Controls.Add(this.z15r);
            this.z15.Controls.Add(this.z15l);
            this.z15.Dock = System.Windows.Forms.DockStyle.Top;
            this.z15.Location = new System.Drawing.Point(0, 1020);
            this.z15.Name = "z15";
            this.z15.Size = new System.Drawing.Size(1063, 30);
            this.z15.TabIndex = 96;
            // 
            // z15r
            // 
            this.z15r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z15r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z15r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z15r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z15r.Location = new System.Drawing.Point(554, 0);
            this.z15r.Name = "z15r";
            this.z15r.Size = new System.Drawing.Size(509, 30);
            this.z15r.TabIndex = 1;
            this.z15r.Text = "0";
            this.z15r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z15l
            // 
            this.z15l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z15l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z15l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z15l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z15l.Location = new System.Drawing.Point(0, 0);
            this.z15l.Name = "z15l";
            this.z15l.Size = new System.Drawing.Size(554, 30);
            this.z15l.TabIndex = 0;
            this.z15l.Text = "0";
            this.z15l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(0, 994);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(1063, 26);
            this.label14.TabIndex = 30;
            this.label14.Text = "Xorijiy davlat professor-o\'qituvchilar soni";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z14
            // 
            this.z14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z14.Controls.Add(this.z14r);
            this.z14.Controls.Add(this.z14l);
            this.z14.Dock = System.Windows.Forms.DockStyle.Top;
            this.z14.Location = new System.Drawing.Point(0, 964);
            this.z14.Name = "z14";
            this.z14.Size = new System.Drawing.Size(1063, 30);
            this.z14.TabIndex = 95;
            // 
            // z14r
            // 
            this.z14r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z14r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z14r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z14r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z14r.Location = new System.Drawing.Point(554, 0);
            this.z14r.Name = "z14r";
            this.z14r.Size = new System.Drawing.Size(509, 30);
            this.z14r.TabIndex = 1;
            this.z14r.Text = "0";
            this.z14r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z14l
            // 
            this.z14l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z14l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z14l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z14l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z14l.Location = new System.Drawing.Point(0, 0);
            this.z14l.Name = "z14l";
            this.z14l.Size = new System.Drawing.Size(554, 30);
            this.z14l.TabIndex = 0;
            this.z14l.Text = "0";
            this.z14l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Dock = System.Windows.Forms.DockStyle.Top;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(0, 938);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(1063, 26);
            this.label13.TabIndex = 28;
            this.label13.Text = "Akademiklar soni";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z13
            // 
            this.z13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z13.Controls.Add(this.z13r);
            this.z13.Controls.Add(this.z13l);
            this.z13.Dock = System.Windows.Forms.DockStyle.Top;
            this.z13.Location = new System.Drawing.Point(0, 908);
            this.z13.Name = "z13";
            this.z13.Size = new System.Drawing.Size(1063, 30);
            this.z13.TabIndex = 94;
            // 
            // z13r
            // 
            this.z13r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z13r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z13r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z13r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z13r.Location = new System.Drawing.Point(554, 0);
            this.z13r.Name = "z13r";
            this.z13r.Size = new System.Drawing.Size(509, 30);
            this.z13r.TabIndex = 1;
            this.z13r.Text = "0";
            this.z13r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z13l
            // 
            this.z13l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z13l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z13l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z13l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z13l.Location = new System.Drawing.Point(0, 0);
            this.z13l.Name = "z13l";
            this.z13l.Size = new System.Drawing.Size(554, 30);
            this.z13l.TabIndex = 0;
            this.z13l.Text = "0";
            this.z13l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(0, 882);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(1063, 26);
            this.label12.TabIndex = 26;
            this.label12.Text = "Professorlar soni";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z12
            // 
            this.z12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z12.Controls.Add(this.z12r);
            this.z12.Controls.Add(this.z12l);
            this.z12.Dock = System.Windows.Forms.DockStyle.Top;
            this.z12.Location = new System.Drawing.Point(0, 852);
            this.z12.Name = "z12";
            this.z12.Size = new System.Drawing.Size(1063, 30);
            this.z12.TabIndex = 93;
            // 
            // z12r
            // 
            this.z12r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z12r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z12r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z12r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z12r.Location = new System.Drawing.Point(554, 0);
            this.z12r.Name = "z12r";
            this.z12r.Size = new System.Drawing.Size(509, 30);
            this.z12r.TabIndex = 1;
            this.z12r.Text = "0";
            this.z12r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z12l
            // 
            this.z12l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z12l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z12l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z12l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z12l.Location = new System.Drawing.Point(0, 0);
            this.z12l.Name = "z12l";
            this.z12l.Size = new System.Drawing.Size(554, 30);
            this.z12l.TabIndex = 0;
            this.z12l.Text = "0";
            this.z12l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(0, 826);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(1063, 26);
            this.label11.TabIndex = 24;
            this.label11.Text = "Dotsentlar soni";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z11
            // 
            this.z11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z11.Controls.Add(this.z11r);
            this.z11.Controls.Add(this.z11l);
            this.z11.Dock = System.Windows.Forms.DockStyle.Top;
            this.z11.Location = new System.Drawing.Point(0, 796);
            this.z11.Name = "z11";
            this.z11.Size = new System.Drawing.Size(1063, 30);
            this.z11.TabIndex = 92;
            // 
            // z11r
            // 
            this.z11r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z11r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z11r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z11r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z11r.Location = new System.Drawing.Point(554, 0);
            this.z11r.Name = "z11r";
            this.z11r.Size = new System.Drawing.Size(509, 30);
            this.z11r.TabIndex = 1;
            this.z11r.Text = "0";
            this.z11r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z11l
            // 
            this.z11l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z11l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z11l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z11l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z11l.Location = new System.Drawing.Point(0, 0);
            this.z11l.Name = "z11l";
            this.z11l.Size = new System.Drawing.Size(554, 30);
            this.z11l.TabIndex = 0;
            this.z11l.Text = "0";
            this.z11l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(0, 770);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1063, 26);
            this.label10.TabIndex = 22;
            this.label10.Text = "O\'qituvchilar soni";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label120
            // 
            this.label120.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label120.Dock = System.Windows.Forms.DockStyle.Top;
            this.label120.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label120.Location = new System.Drawing.Point(0, 740);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(1063, 30);
            this.label120.TabIndex = 121;
            this.label120.Text = "O\'qituvchilar";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z10
            // 
            this.z10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z10.Controls.Add(this.z10r);
            this.z10.Controls.Add(this.z10l);
            this.z10.Dock = System.Windows.Forms.DockStyle.Top;
            this.z10.Location = new System.Drawing.Point(0, 710);
            this.z10.Name = "z10";
            this.z10.Size = new System.Drawing.Size(1063, 30);
            this.z10.TabIndex = 91;
            // 
            // z10r
            // 
            this.z10r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z10r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z10r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z10r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z10r.Location = new System.Drawing.Point(554, 0);
            this.z10r.Name = "z10r";
            this.z10r.Size = new System.Drawing.Size(509, 30);
            this.z10r.TabIndex = 1;
            this.z10r.Text = "0";
            this.z10r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z10l
            // 
            this.z10l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z10l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z10l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z10l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z10l.Location = new System.Drawing.Point(0, 0);
            this.z10l.Name = "z10l";
            this.z10l.Size = new System.Drawing.Size(554, 30);
            this.z10l.TabIndex = 0;
            this.z10l.Text = "0";
            this.z10l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(0, 684);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(1063, 26);
            this.label9.TabIndex = 20;
            this.label9.Text = "Veb sayti";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z9
            // 
            this.z9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z9.Controls.Add(this.z9r);
            this.z9.Controls.Add(this.z9l);
            this.z9.Dock = System.Windows.Forms.DockStyle.Top;
            this.z9.Location = new System.Drawing.Point(0, 654);
            this.z9.Name = "z9";
            this.z9.Size = new System.Drawing.Size(1063, 30);
            this.z9.TabIndex = 90;
            // 
            // z9r
            // 
            this.z9r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z9r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z9r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z9r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z9r.Location = new System.Drawing.Point(554, 0);
            this.z9r.Name = "z9r";
            this.z9r.Size = new System.Drawing.Size(509, 30);
            this.z9r.TabIndex = 1;
            this.z9r.Text = "0";
            this.z9r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z9l
            // 
            this.z9l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z9l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z9l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z9l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z9l.Location = new System.Drawing.Point(0, 0);
            this.z9l.Name = "z9l";
            this.z9l.Size = new System.Drawing.Size(554, 30);
            this.z9l.TabIndex = 0;
            this.z9l.Text = "0";
            this.z9l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(0, 628);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(1063, 26);
            this.label8.TabIndex = 18;
            this.label8.Text = "Email";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z8
            // 
            this.z8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z8.Controls.Add(this.z8r);
            this.z8.Controls.Add(this.z8l);
            this.z8.Dock = System.Windows.Forms.DockStyle.Top;
            this.z8.Location = new System.Drawing.Point(0, 598);
            this.z8.Name = "z8";
            this.z8.Size = new System.Drawing.Size(1063, 30);
            this.z8.TabIndex = 89;
            // 
            // z8r
            // 
            this.z8r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z8r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z8r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z8r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z8r.Location = new System.Drawing.Point(554, 0);
            this.z8r.Name = "z8r";
            this.z8r.Size = new System.Drawing.Size(509, 30);
            this.z8r.TabIndex = 1;
            this.z8r.Text = "0";
            this.z8r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z8l
            // 
            this.z8l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z8l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z8l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z8l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z8l.Location = new System.Drawing.Point(0, 0);
            this.z8l.Name = "z8l";
            this.z8l.Size = new System.Drawing.Size(554, 30);
            this.z8l.TabIndex = 0;
            this.z8l.Text = "0";
            this.z8l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(0, 572);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(1063, 26);
            this.label7.TabIndex = 16;
            this.label7.Text = "Telefon raqam";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z7
            // 
            this.z7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z7.Controls.Add(this.z7r);
            this.z7.Controls.Add(this.z7l);
            this.z7.Dock = System.Windows.Forms.DockStyle.Top;
            this.z7.Location = new System.Drawing.Point(0, 542);
            this.z7.Name = "z7";
            this.z7.Size = new System.Drawing.Size(1063, 30);
            this.z7.TabIndex = 88;
            // 
            // z7r
            // 
            this.z7r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z7r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z7r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z7r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z7r.Location = new System.Drawing.Point(554, 0);
            this.z7r.Name = "z7r";
            this.z7r.Size = new System.Drawing.Size(509, 30);
            this.z7r.TabIndex = 1;
            this.z7r.Text = "0";
            this.z7r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z7l
            // 
            this.z7l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z7l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z7l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z7l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z7l.Location = new System.Drawing.Point(0, 0);
            this.z7l.Name = "z7l";
            this.z7l.Size = new System.Drawing.Size(554, 30);
            this.z7l.TabIndex = 0;
            this.z7l.Text = "0";
            this.z7l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(0, 516);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(1063, 26);
            this.label6.TabIndex = 14;
            this.label6.Text = "Tashkil etilgan yili";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z6
            // 
            this.z6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z6.Controls.Add(this.z6r);
            this.z6.Controls.Add(this.z6l);
            this.z6.Dock = System.Windows.Forms.DockStyle.Top;
            this.z6.Location = new System.Drawing.Point(0, 486);
            this.z6.Name = "z6";
            this.z6.Size = new System.Drawing.Size(1063, 30);
            this.z6.TabIndex = 87;
            // 
            // z6r
            // 
            this.z6r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z6r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z6r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z6r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z6r.Location = new System.Drawing.Point(554, 0);
            this.z6r.Name = "z6r";
            this.z6r.Size = new System.Drawing.Size(509, 30);
            this.z6r.TabIndex = 1;
            this.z6r.Text = "0";
            this.z6r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z6l
            // 
            this.z6l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z6l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z6l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z6l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z6l.Location = new System.Drawing.Point(0, 0);
            this.z6l.Name = "z6l";
            this.z6l.Size = new System.Drawing.Size(554, 30);
            this.z6l.TabIndex = 0;
            this.z6l.Text = "0";
            this.z6l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(0, 460);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(1063, 26);
            this.label5.TabIndex = 12;
            this.label5.Text = "Holat(Davlat, Nodavlat yoki Xorijiy)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z5
            // 
            this.z5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z5.Controls.Add(this.z5r);
            this.z5.Controls.Add(this.z5l);
            this.z5.Dock = System.Windows.Forms.DockStyle.Top;
            this.z5.Location = new System.Drawing.Point(0, 430);
            this.z5.Name = "z5";
            this.z5.Size = new System.Drawing.Size(1063, 30);
            this.z5.TabIndex = 86;
            // 
            // z5r
            // 
            this.z5r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z5r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z5r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z5r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z5r.Location = new System.Drawing.Point(554, 0);
            this.z5r.Name = "z5r";
            this.z5r.Size = new System.Drawing.Size(509, 30);
            this.z5r.TabIndex = 1;
            this.z5r.Text = "0";
            this.z5r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z5l
            // 
            this.z5l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z5l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z5l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z5l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z5l.Location = new System.Drawing.Point(0, 0);
            this.z5l.Name = "z5l";
            this.z5l.Size = new System.Drawing.Size(554, 30);
            this.z5l.TabIndex = 0;
            this.z5l.Text = "0";
            this.z5l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(0, 404);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1063, 26);
            this.label4.TabIndex = 10;
            this.label4.Text = "Manzil (Shahar yoki tuman, ko\'cha va uy(bino))";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z4
            // 
            this.z4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z4.Controls.Add(this.z4r);
            this.z4.Controls.Add(this.z4l);
            this.z4.Dock = System.Windows.Forms.DockStyle.Top;
            this.z4.Location = new System.Drawing.Point(0, 374);
            this.z4.Name = "z4";
            this.z4.Size = new System.Drawing.Size(1063, 30);
            this.z4.TabIndex = 85;
            // 
            // z4r
            // 
            this.z4r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z4r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z4r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z4r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z4r.Location = new System.Drawing.Point(554, 0);
            this.z4r.Name = "z4r";
            this.z4r.Size = new System.Drawing.Size(509, 30);
            this.z4r.TabIndex = 1;
            this.z4r.Text = "0";
            this.z4r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z4l
            // 
            this.z4l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z4l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z4l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z4l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z4l.Location = new System.Drawing.Point(0, 0);
            this.z4l.Name = "z4l";
            this.z4l.Size = new System.Drawing.Size(554, 30);
            this.z4l.TabIndex = 0;
            this.z4l.Text = "0";
            this.z4l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(0, 348);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1063, 26);
            this.label3.TabIndex = 7;
            this.label3.Text = "Viloyat";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z3
            // 
            this.z3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z3.Controls.Add(this.z3r);
            this.z3.Controls.Add(this.z3l);
            this.z3.Dock = System.Windows.Forms.DockStyle.Top;
            this.z3.Location = new System.Drawing.Point(0, 168);
            this.z3.Name = "z3";
            this.z3.Size = new System.Drawing.Size(1063, 180);
            this.z3.TabIndex = 84;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Dock = System.Windows.Forms.DockStyle.Top;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(0, 142);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(1063, 26);
            this.label39.TabIndex = 5;
            this.label39.Text = "Rasm";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z2
            // 
            this.z2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z2.Controls.Add(this.z2r);
            this.z2.Controls.Add(this.z2l);
            this.z2.Dock = System.Windows.Forms.DockStyle.Top;
            this.z2.Location = new System.Drawing.Point(0, 112);
            this.z2.Name = "z2";
            this.z2.Size = new System.Drawing.Size(1063, 30);
            this.z2.TabIndex = 83;
            // 
            // z2r
            // 
            this.z2r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z2r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z2r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z2r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z2r.Location = new System.Drawing.Point(554, 0);
            this.z2r.Name = "z2r";
            this.z2r.Size = new System.Drawing.Size(509, 30);
            this.z2r.TabIndex = 1;
            this.z2r.Text = "0";
            this.z2r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z2l
            // 
            this.z2l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z2l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z2l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z2l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z2l.Location = new System.Drawing.Point(0, 0);
            this.z2l.Name = "z2l";
            this.z2l.Size = new System.Drawing.Size(554, 30);
            this.z2l.TabIndex = 0;
            this.z2l.Text = "0";
            this.z2l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Dock = System.Windows.Forms.DockStyle.Top;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(0, 86);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(1063, 26);
            this.label40.TabIndex = 3;
            this.label40.Text = "Nom";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z1
            // 
            this.z1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.z1.Controls.Add(this.z1r);
            this.z1.Controls.Add(this.z1l);
            this.z1.Dock = System.Windows.Forms.DockStyle.Top;
            this.z1.Location = new System.Drawing.Point(0, 56);
            this.z1.Name = "z1";
            this.z1.Size = new System.Drawing.Size(1063, 30);
            this.z1.TabIndex = 82;
            // 
            // z1r
            // 
            this.z1r.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z1r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z1r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z1r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z1r.Location = new System.Drawing.Point(554, 0);
            this.z1r.Name = "z1r";
            this.z1r.Size = new System.Drawing.Size(509, 30);
            this.z1r.TabIndex = 1;
            this.z1r.Text = "0";
            this.z1r.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // z1l
            // 
            this.z1l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.z1l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z1l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z1l.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z1l.Location = new System.Drawing.Point(0, 0);
            this.z1l.Name = "z1l";
            this.z1l.Size = new System.Drawing.Size(554, 30);
            this.z1l.TabIndex = 0;
            this.z1l.Text = "0";
            this.z1l.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // zId
            // 
            this.zId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.zId.Dock = System.Windows.Forms.DockStyle.Top;
            this.zId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.zId.ForeColor = System.Drawing.Color.White;
            this.zId.Location = new System.Drawing.Point(0, 30);
            this.zId.Name = "zId";
            this.zId.Size = new System.Drawing.Size(1063, 26);
            this.zId.TabIndex = 2;
            this.zId.Text = "ID";
            this.zId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label119
            // 
            this.label119.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label119.Dock = System.Windows.Forms.DockStyle.Top;
            this.label119.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label119.Location = new System.Drawing.Point(0, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(1063, 30);
            this.label119.TabIndex = 130;
            this.label119.Text = "Oliy ta\'lim muassasasi haqida";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // z39l
            // 
            this.z39l.BackColor = System.Drawing.SystemColors.Window;
            this.z39l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z39l.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z39l.FormattingEnabled = true;
            this.z39l.ItemHeight = 25;
            this.z39l.Location = new System.Drawing.Point(0, 0);
            this.z39l.Name = "z39l";
            this.z39l.ScrollAlwaysVisible = true;
            this.z39l.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.z39l.Size = new System.Drawing.Size(552, 90);
            this.z39l.Sorted = true;
            this.z39l.TabIndex = 10;
            this.z39l.TabStop = false;
            // 
            // z39r
            // 
            this.z39r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z39r.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.z39r.FormattingEnabled = true;
            this.z39r.ItemHeight = 25;
            this.z39r.Location = new System.Drawing.Point(552, 0);
            this.z39r.Name = "z39r";
            this.z39r.ScrollAlwaysVisible = true;
            this.z39r.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.z39r.Size = new System.Drawing.Size(511, 90);
            this.z39r.Sorted = true;
            this.z39r.TabIndex = 10;
            this.z39r.TabStop = false;
            // 
            // z3l
            // 
            this.z3l.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z3l.Dock = System.Windows.Forms.DockStyle.Left;
            this.z3l.Location = new System.Drawing.Point(0, 0);
            this.z3l.Name = "z3l";
            this.z3l.Size = new System.Drawing.Size(554, 180);
            this.z3l.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.z3l.TabIndex = 2;
            this.z3l.TabStop = false;
            // 
            // z3r
            // 
            this.z3r.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.z3r.Dock = System.Windows.Forms.DockStyle.Fill;
            this.z3r.Location = new System.Drawing.Point(554, 0);
            this.z3r.Name = "z3r";
            this.z3r.Size = new System.Drawing.Size(509, 180);
            this.z3r.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.z3r.TabIndex = 3;
            this.z3r.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(79, 34);
            this.textBox1.TabIndex = 0;
            // 
            // labelTop
            // 
            this.labelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.labelTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelTop.Location = new System.Drawing.Point(0, 0);
            this.labelTop.Name = "labelTop";
            this.labelTop.Size = new System.Drawing.Size(1088, 30);
            this.labelTop.TabIndex = 131;
            this.labelTop.Text = "Umumiy natija";
            this.labelTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Taqqoslash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Universitetlarni_taqqoslash.Properties.Resources.vs_background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1088, 567);
            this.Controls.Add(this.panelVS);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1106, 614);
            this.Name = "Taqqoslash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Taqqoslash";
            this.Load += new System.EventHandler(this.Taqqoslash_Load);
            this.panelTop.ResumeLayout(false);
            this.panelVS.ResumeLayout(false);
            this.panelOTMData.ResumeLayout(false);
            this.panelOTMData.PerformLayout();
            this.z39.ResumeLayout(false);
            this.z38.ResumeLayout(false);
            this.z37.ResumeLayout(false);
            this.z36.ResumeLayout(false);
            this.z35.ResumeLayout(false);
            this.z34.ResumeLayout(false);
            this.z33.ResumeLayout(false);
            this.z32.ResumeLayout(false);
            this.z31.ResumeLayout(false);
            this.z30.ResumeLayout(false);
            this.z29.ResumeLayout(false);
            this.z28.ResumeLayout(false);
            this.z27.ResumeLayout(false);
            this.z26.ResumeLayout(false);
            this.z25.ResumeLayout(false);
            this.z24.ResumeLayout(false);
            this.z23.ResumeLayout(false);
            this.z22.ResumeLayout(false);
            this.z21.ResumeLayout(false);
            this.z20.ResumeLayout(false);
            this.z19.ResumeLayout(false);
            this.z18.ResumeLayout(false);
            this.z17.ResumeLayout(false);
            this.z16.ResumeLayout(false);
            this.z15.ResumeLayout(false);
            this.z14.ResumeLayout(false);
            this.z13.ResumeLayout(false);
            this.z12.ResumeLayout(false);
            this.z11.ResumeLayout(false);
            this.z10.ResumeLayout(false);
            this.z9.ResumeLayout(false);
            this.z8.ResumeLayout(false);
            this.z7.ResumeLayout(false);
            this.z6.ResumeLayout(false);
            this.z5.ResumeLayout(false);
            this.z4.ResumeLayout(false);
            this.z3.ResumeLayout(false);
            this.z2.ResumeLayout(false);
            this.z1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.z3l)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.z3r)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelVS;
        private System.Windows.Forms.Label resultr;
        private System.Windows.Forms.Label resultl;
        private System.Windows.Forms.Panel panelOTMData;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label zId;
        private System.Windows.Forms.Panel z1;
        private System.Windows.Forms.Label z1r;
        private System.Windows.Forms.Label z1l;
        private System.Windows.Forms.Panel z10;
        private System.Windows.Forms.Label z10r;
        private System.Windows.Forms.Label z10l;
        private System.Windows.Forms.Panel z9;
        private System.Windows.Forms.Label z9r;
        private System.Windows.Forms.Label z9l;
        private System.Windows.Forms.Panel z8;
        private System.Windows.Forms.Label z8r;
        private System.Windows.Forms.Label z8l;
        private System.Windows.Forms.Panel z7;
        private System.Windows.Forms.Label z7r;
        private System.Windows.Forms.Label z7l;
        private System.Windows.Forms.Panel z6;
        private System.Windows.Forms.Label z6r;
        private System.Windows.Forms.Label z6l;
        private System.Windows.Forms.Panel z5;
        private System.Windows.Forms.Label z5r;
        private System.Windows.Forms.Label z5l;
        private System.Windows.Forms.Panel z4;
        private System.Windows.Forms.Label z4r;
        private System.Windows.Forms.Label z4l;
        private System.Windows.Forms.Panel z3;
        private System.Windows.Forms.Panel z2;
        private System.Windows.Forms.Label z2r;
        private System.Windows.Forms.Label z2l;
        private System.Windows.Forms.Panel z39;
        private System.Windows.Forms.Panel z38;
        private System.Windows.Forms.Label z38r;
        private System.Windows.Forms.Label z38l;
        private System.Windows.Forms.Panel z37;
        private System.Windows.Forms.Label z37r;
        private System.Windows.Forms.Label z37l;
        private System.Windows.Forms.Panel z36;
        private System.Windows.Forms.Label z36r;
        private System.Windows.Forms.Label z36l;
        private System.Windows.Forms.Panel z35;
        private System.Windows.Forms.Label z35r;
        private System.Windows.Forms.Label z35l;
        private System.Windows.Forms.Panel z34;
        private System.Windows.Forms.Label z34r;
        private System.Windows.Forms.Label z34l;
        private System.Windows.Forms.Panel z33;
        private System.Windows.Forms.Label z33r;
        private System.Windows.Forms.Label z33l;
        private System.Windows.Forms.Panel z32;
        private System.Windows.Forms.Label z32r;
        private System.Windows.Forms.Label z32l;
        private System.Windows.Forms.Panel z31;
        private System.Windows.Forms.Label z31r;
        private System.Windows.Forms.Label z31l;
        private System.Windows.Forms.Panel z30;
        private System.Windows.Forms.Label z30r;
        private System.Windows.Forms.Label z30l;
        private System.Windows.Forms.Panel z29;
        private System.Windows.Forms.Label z29r;
        private System.Windows.Forms.Label z29l;
        private System.Windows.Forms.Panel z28;
        private System.Windows.Forms.Label z28r;
        private System.Windows.Forms.Label z28l;
        private System.Windows.Forms.Panel z27;
        private System.Windows.Forms.Label z27r;
        private System.Windows.Forms.Label z27l;
        private System.Windows.Forms.Panel z26;
        private System.Windows.Forms.Label z26r;
        private System.Windows.Forms.Label z26l;
        private System.Windows.Forms.Panel z25;
        private System.Windows.Forms.Label z25r;
        private System.Windows.Forms.Label z25l;
        private System.Windows.Forms.Panel z24;
        private System.Windows.Forms.Label z24r;
        private System.Windows.Forms.Label z24l;
        private System.Windows.Forms.Panel z23;
        private System.Windows.Forms.Label z23r;
        private System.Windows.Forms.Label z23l;
        private System.Windows.Forms.Panel z22;
        private System.Windows.Forms.Label z22r;
        private System.Windows.Forms.Label z22l;
        private System.Windows.Forms.Panel z21;
        private System.Windows.Forms.Label z21r;
        private System.Windows.Forms.Label z21l;
        private System.Windows.Forms.Panel z20;
        private System.Windows.Forms.Label z20r;
        private System.Windows.Forms.Label z20l;
        private System.Windows.Forms.Panel z19;
        private System.Windows.Forms.Label z19r;
        private System.Windows.Forms.Label z19l;
        private System.Windows.Forms.Panel z18;
        private System.Windows.Forms.Label z18r;
        private System.Windows.Forms.Label z18l;
        private System.Windows.Forms.Panel z17;
        private System.Windows.Forms.Label z17r;
        private System.Windows.Forms.Label z17l;
        private System.Windows.Forms.Panel z16;
        private System.Windows.Forms.Label z16r;
        private System.Windows.Forms.Label z16l;
        private System.Windows.Forms.Panel z15;
        private System.Windows.Forms.Label z15r;
        private System.Windows.Forms.Label z15l;
        private System.Windows.Forms.Panel z14;
        private System.Windows.Forms.Label z14r;
        private System.Windows.Forms.Label z14l;
        private System.Windows.Forms.Panel z13;
        private System.Windows.Forms.Label z13r;
        private System.Windows.Forms.Label z13l;
        private System.Windows.Forms.Panel z12;
        private System.Windows.Forms.Label z12r;
        private System.Windows.Forms.Label z12l;
        private System.Windows.Forms.Panel z11;
        private System.Windows.Forms.Label z11r;
        private System.Windows.Forms.Label z11l;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.ListBox z39l;
        private System.Windows.Forms.ListBox z39r;
        private System.Windows.Forms.PictureBox z3r;
        private System.Windows.Forms.PictureBox z3l;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelTop;
    }
}