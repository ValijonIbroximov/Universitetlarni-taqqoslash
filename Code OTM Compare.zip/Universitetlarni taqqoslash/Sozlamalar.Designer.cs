﻿namespace Universitetlarni_taqqoslash
{
    partial class Sozlamalar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sozlamalar));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.malumotlarBazasiBilanBoglashToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiqishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parolniAlmashtirishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flowLayoutPanelOTMlar = new System.Windows.Forms.FlowLayoutPanel();
            this.panelYonalishlar = new System.Windows.Forms.Panel();
            this.dataGridViewYonalish = new System.Windows.Forms.DataGridView();
            this.textBoxYonalish = new System.Windows.Forms.TextBox();
            this.labelYonalishID = new System.Windows.Forms.Label();
            this.menuStrip3 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.zRasm = new System.Windows.Forms.PictureBox();
            this.zId = new System.Windows.Forms.Label();
            this.panelOTMedit = new System.Windows.Forms.Panel();
            this.panelOTMData = new System.Windows.Forms.Panel();
            this.zTalim_yonalishlari_ids = new System.Windows.Forms.CheckedListBox();
            this.label37 = new System.Windows.Forms.Label();
            this.zFakultetlar_soni = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.zKontrakt_joylar = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.zGrant_joylar = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.zAjratilgan_joylar = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.zYotoqxona_tolovi = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.zOrtacha_kontrakt_tolovi = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.zOrtacha_stipendiya = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.zYotoqxona_sigimi = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.zOquv_bino_sigimi = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.zAxborot_resurslari_soni = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.zOrtacha_GPA = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.zUmumiy_qarz = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.zQarzdor_talabalar_soni = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.zIsh_bilan_bandlik = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.zBitiruvchilar_soni = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.zXorijiy_talabalar_soni = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.zAyol_talabalar_soni = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.zErkak_talabalar_soni = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.zTalabalar_soni = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.zOqituvchilar_KPI = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.zTadqiqot_mablaglari = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.zIlmiy_iqtiboslar_soni = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.zIlmiy_maqolalar_soni = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.zXorijiy_oqituvchilar_soni = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.zAkademiklar_soni = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.zProfessorlar_soni = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.zDontsentlar_soni = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.zOqituvchilar_soni = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.zVeb_sayti = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.zEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.zTelefon = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.zTashkil_etilgan_yili = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.zHolat = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.zShahar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.zViloyat = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.zNom = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panelYonalishlar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYonalish)).BeginInit();
            this.menuStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zRasm)).BeginInit();
            this.panelOTMedit.SuspendLayout();
            this.panelOTMData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zFakultetlar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zKontrakt_joylar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zGrant_joylar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAjratilgan_joylar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zYotoqxona_tolovi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOrtacha_kontrakt_tolovi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOrtacha_stipendiya)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zYotoqxona_sigimi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOquv_bino_sigimi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAxborot_resurslari_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOrtacha_GPA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zUmumiy_qarz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zQarzdor_talabalar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zIsh_bilan_bandlik)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zBitiruvchilar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zXorijiy_talabalar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAyol_talabalar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zErkak_talabalar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zTalabalar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOqituvchilar_KPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zTadqiqot_mablaglari)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zIlmiy_iqtiboslar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zIlmiy_maqolalar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zXorijiy_oqituvchilar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAkademiklar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zProfessorlar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zDontsentlar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOqituvchilar_soni)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zTashkil_etilgan_yili)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.malumotlarBazasiBilanBoglashToolStripMenuItem,
            this.chiqishToolStripMenuItem,
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem,
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem,
            this.parolniAlmashtirishToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1088, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // malumotlarBazasiBilanBoglashToolStripMenuItem
            // 
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Image = global::Universitetlarni_taqqoslash.Properties.Resources.api;
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Name = "malumotlarBazasiBilanBoglashToolStripMenuItem";
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Size = new System.Drawing.Size(491, 32);
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Text = "Ma\'lumotlar bazasi bilan bog\'lash yoki almashtirish";
            this.malumotlarBazasiBilanBoglashToolStripMenuItem.Click += new System.EventHandler(this.malumotlarBazasiBilanBoglashToolStripMenuItem_Click);
            // 
            // chiqishToolStripMenuItem
            // 
            this.chiqishToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.chiqishToolStripMenuItem.BackColor = System.Drawing.Color.LightCoral;
            this.chiqishToolStripMenuItem.Image = global::Universitetlarni_taqqoslash.Properties.Resources.chiqish;
            this.chiqishToolStripMenuItem.Name = "chiqishToolStripMenuItem";
            this.chiqishToolStripMenuItem.Size = new System.Drawing.Size(110, 32);
            this.chiqishToolStripMenuItem.Text = "Chiqish";
            this.chiqishToolStripMenuItem.Click += new System.EventHandler(this.chiqishToolStripMenuItem_Click);
            // 
            // yangiMalumotlarBazasiYaratishToolStripMenuItem
            // 
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Image = global::Universitetlarni_taqqoslash.Properties.Resources.add_database;
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Name = "yangiMalumotlarBazasiYaratishToolStripMenuItem";
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Size = new System.Drawing.Size(336, 32);
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Text = "Yangi ma\'lumotlar bazasi yaratish";
            this.yangiMalumotlarBazasiYaratishToolStripMenuItem.Click += new System.EventHandler(this.yangiMalumotlarBazasiYaratishToolStripMenuItem_Click);
            // 
            // malumotlarBazasiJoylashuviniKorishToolStripMenuItem
            // 
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem.Image = global::Universitetlarni_taqqoslash.Properties.Resources.location;
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem.Name = "malumotlarBazasiJoylashuviniKorishToolStripMenuItem";
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem.Size = new System.Drawing.Size(383, 32);
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem.Text = "Ma\'lumotlar bazasi joylashuvini ko\'rish";
            this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem.Click += new System.EventHandler(this.malumotlarBazasiJoylashuviniKorishToolStripMenuItem_Click);
            // 
            // parolniAlmashtirishToolStripMenuItem
            // 
            this.parolniAlmashtirishToolStripMenuItem.Image = global::Universitetlarni_taqqoslash.Properties.Resources.reset_password;
            this.parolniAlmashtirishToolStripMenuItem.Name = "parolniAlmashtirishToolStripMenuItem";
            this.parolniAlmashtirishToolStripMenuItem.Size = new System.Drawing.Size(215, 32);
            this.parolniAlmashtirishToolStripMenuItem.Text = "Parolni almashtirish";
            this.parolniAlmashtirishToolStripMenuItem.Click += new System.EventHandler(this.parolniAlmashtirishToolStripMenuItem_Click);
            // 
            // flowLayoutPanelOTMlar
            // 
            this.flowLayoutPanelOTMlar.AutoScroll = true;
            this.flowLayoutPanelOTMlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.flowLayoutPanelOTMlar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanelOTMlar.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanelOTMlar.Location = new System.Drawing.Point(0, 36);
            this.flowLayoutPanelOTMlar.Name = "flowLayoutPanelOTMlar";
            this.flowLayoutPanelOTMlar.Size = new System.Drawing.Size(300, 531);
            this.flowLayoutPanelOTMlar.TabIndex = 1;
            // 
            // panelYonalishlar
            // 
            this.panelYonalishlar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelYonalishlar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelYonalishlar.Controls.Add(this.dataGridViewYonalish);
            this.panelYonalishlar.Controls.Add(this.textBoxYonalish);
            this.panelYonalishlar.Controls.Add(this.labelYonalishID);
            this.panelYonalishlar.Controls.Add(this.menuStrip3);
            this.panelYonalishlar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelYonalishlar.Location = new System.Drawing.Point(300, 267);
            this.panelYonalishlar.Name = "panelYonalishlar";
            this.panelYonalishlar.Size = new System.Drawing.Size(788, 300);
            this.panelYonalishlar.TabIndex = 4;
            // 
            // dataGridViewYonalish
            // 
            this.dataGridViewYonalish.BackgroundColor = System.Drawing.Color.Silver;
            this.dataGridViewYonalish.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewYonalish.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewYonalish.GridColor = System.Drawing.Color.Silver;
            this.dataGridViewYonalish.Location = new System.Drawing.Point(0, 88);
            this.dataGridViewYonalish.Name = "dataGridViewYonalish";
            this.dataGridViewYonalish.RowHeadersWidth = 51;
            this.dataGridViewYonalish.RowTemplate.Height = 24;
            this.dataGridViewYonalish.Size = new System.Drawing.Size(784, 208);
            this.dataGridViewYonalish.TabIndex = 3;
            this.dataGridViewYonalish.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewYonalish_CellClick);
            // 
            // textBoxYonalish
            // 
            this.textBoxYonalish.BackColor = System.Drawing.Color.Silver;
            this.textBoxYonalish.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxYonalish.Location = new System.Drawing.Point(0, 54);
            this.textBoxYonalish.Name = "textBoxYonalish";
            this.textBoxYonalish.Size = new System.Drawing.Size(784, 34);
            this.textBoxYonalish.TabIndex = 2;
            // 
            // labelYonalishID
            // 
            this.labelYonalishID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelYonalishID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelYonalishID.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelYonalishID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelYonalishID.ForeColor = System.Drawing.Color.White;
            this.labelYonalishID.Location = new System.Drawing.Point(0, 28);
            this.labelYonalishID.Name = "labelYonalishID";
            this.labelYonalishID.Size = new System.Drawing.Size(784, 26);
            this.labelYonalishID.TabIndex = 4;
            this.labelYonalishID.Text = "ID: ";
            this.labelYonalishID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // menuStrip3
            // 
            this.menuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.menuStrip3.Location = new System.Drawing.Point(0, 0);
            this.menuStrip3.Name = "menuStrip3";
            this.menuStrip3.Size = new System.Drawing.Size(784, 28);
            this.menuStrip3.TabIndex = 1;
            this.menuStrip3.Text = "menuStrip3";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = global::Universitetlarni_taqqoslash.Properties.Resources.add;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(98, 24);
            this.toolStripMenuItem1.Text = "Qo\'shish";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::Universitetlarni_taqqoslash.Properties.Resources.rubber;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(100, 24);
            this.toolStripMenuItem2.Text = "Tozalash";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::Universitetlarni_taqqoslash.Properties.Resources.upgrade;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(105, 24);
            this.toolStripMenuItem3.Text = "Yangilash";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Image = global::Universitetlarni_taqqoslash.Properties.Resources.delete;
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(99, 24);
            this.toolStripMenuItem4.Text = "O\'chirish";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 5000;
            this.toolTip1.InitialDelay = 100;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 100;
            // 
            // zRasm
            // 
            this.zRasm.AccessibleDescription = "";
            this.zRasm.AccessibleName = "";
            this.zRasm.Dock = System.Windows.Forms.DockStyle.Top;
            this.zRasm.Location = new System.Drawing.Point(0, 112);
            this.zRasm.Name = "zRasm";
            this.zRasm.Size = new System.Drawing.Size(763, 184);
            this.zRasm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.zRasm.TabIndex = 6;
            this.zRasm.TabStop = false;
            this.toolTip1.SetToolTip(this.zRasm, "Rasm kiritish uchun ikki marta bosing");
            this.zRasm.DoubleClick += new System.EventHandler(this.zRasm_DoubleClick);
            // 
            // zId
            // 
            this.zId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.zId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.zId.Dock = System.Windows.Forms.DockStyle.Top;
            this.zId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.zId.ForeColor = System.Drawing.Color.White;
            this.zId.Location = new System.Drawing.Point(0, 0);
            this.zId.Name = "zId";
            this.zId.Size = new System.Drawing.Size(763, 26);
            this.zId.TabIndex = 2;
            this.zId.Text = "ID: ";
            this.zId.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolTip1.SetToolTip(this.zId, "ID dastur tomonidan avtomatik kiritiladi");
            // 
            // panelOTMedit
            // 
            this.panelOTMedit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelOTMedit.Controls.Add(this.panelOTMData);
            this.panelOTMedit.Controls.Add(this.menuStrip2);
            this.panelOTMedit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOTMedit.Location = new System.Drawing.Point(300, 36);
            this.panelOTMedit.Name = "panelOTMedit";
            this.panelOTMedit.Size = new System.Drawing.Size(788, 231);
            this.panelOTMedit.TabIndex = 6;
            // 
            // panelOTMData
            // 
            this.panelOTMData.AutoScroll = true;
            this.panelOTMData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panelOTMData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelOTMData.Controls.Add(this.zTalim_yonalishlari_ids);
            this.panelOTMData.Controls.Add(this.label37);
            this.panelOTMData.Controls.Add(this.zFakultetlar_soni);
            this.panelOTMData.Controls.Add(this.label36);
            this.panelOTMData.Controls.Add(this.zKontrakt_joylar);
            this.panelOTMData.Controls.Add(this.label35);
            this.panelOTMData.Controls.Add(this.zGrant_joylar);
            this.panelOTMData.Controls.Add(this.label34);
            this.panelOTMData.Controls.Add(this.zAjratilgan_joylar);
            this.panelOTMData.Controls.Add(this.label33);
            this.panelOTMData.Controls.Add(this.zYotoqxona_tolovi);
            this.panelOTMData.Controls.Add(this.label32);
            this.panelOTMData.Controls.Add(this.zOrtacha_kontrakt_tolovi);
            this.panelOTMData.Controls.Add(this.label31);
            this.panelOTMData.Controls.Add(this.zOrtacha_stipendiya);
            this.panelOTMData.Controls.Add(this.label30);
            this.panelOTMData.Controls.Add(this.zYotoqxona_sigimi);
            this.panelOTMData.Controls.Add(this.label29);
            this.panelOTMData.Controls.Add(this.zOquv_bino_sigimi);
            this.panelOTMData.Controls.Add(this.label28);
            this.panelOTMData.Controls.Add(this.zAxborot_resurslari_soni);
            this.panelOTMData.Controls.Add(this.label27);
            this.panelOTMData.Controls.Add(this.zOrtacha_GPA);
            this.panelOTMData.Controls.Add(this.label26);
            this.panelOTMData.Controls.Add(this.zUmumiy_qarz);
            this.panelOTMData.Controls.Add(this.label25);
            this.panelOTMData.Controls.Add(this.zQarzdor_talabalar_soni);
            this.panelOTMData.Controls.Add(this.label24);
            this.panelOTMData.Controls.Add(this.zIsh_bilan_bandlik);
            this.panelOTMData.Controls.Add(this.label23);
            this.panelOTMData.Controls.Add(this.zBitiruvchilar_soni);
            this.panelOTMData.Controls.Add(this.label22);
            this.panelOTMData.Controls.Add(this.zXorijiy_talabalar_soni);
            this.panelOTMData.Controls.Add(this.label21);
            this.panelOTMData.Controls.Add(this.zAyol_talabalar_soni);
            this.panelOTMData.Controls.Add(this.label20);
            this.panelOTMData.Controls.Add(this.zErkak_talabalar_soni);
            this.panelOTMData.Controls.Add(this.label19);
            this.panelOTMData.Controls.Add(this.zTalabalar_soni);
            this.panelOTMData.Controls.Add(this.label18);
            this.panelOTMData.Controls.Add(this.zOqituvchilar_KPI);
            this.panelOTMData.Controls.Add(this.label17);
            this.panelOTMData.Controls.Add(this.zTadqiqot_mablaglari);
            this.panelOTMData.Controls.Add(this.label38);
            this.panelOTMData.Controls.Add(this.zIlmiy_iqtiboslar_soni);
            this.panelOTMData.Controls.Add(this.label16);
            this.panelOTMData.Controls.Add(this.zIlmiy_maqolalar_soni);
            this.panelOTMData.Controls.Add(this.label15);
            this.panelOTMData.Controls.Add(this.zXorijiy_oqituvchilar_soni);
            this.panelOTMData.Controls.Add(this.label14);
            this.panelOTMData.Controls.Add(this.zAkademiklar_soni);
            this.panelOTMData.Controls.Add(this.label13);
            this.panelOTMData.Controls.Add(this.zProfessorlar_soni);
            this.panelOTMData.Controls.Add(this.label12);
            this.panelOTMData.Controls.Add(this.zDontsentlar_soni);
            this.panelOTMData.Controls.Add(this.label11);
            this.panelOTMData.Controls.Add(this.zOqituvchilar_soni);
            this.panelOTMData.Controls.Add(this.label10);
            this.panelOTMData.Controls.Add(this.zVeb_sayti);
            this.panelOTMData.Controls.Add(this.label9);
            this.panelOTMData.Controls.Add(this.zEmail);
            this.panelOTMData.Controls.Add(this.label8);
            this.panelOTMData.Controls.Add(this.zTelefon);
            this.panelOTMData.Controls.Add(this.label7);
            this.panelOTMData.Controls.Add(this.zTashkil_etilgan_yili);
            this.panelOTMData.Controls.Add(this.label6);
            this.panelOTMData.Controls.Add(this.zHolat);
            this.panelOTMData.Controls.Add(this.label5);
            this.panelOTMData.Controls.Add(this.zShahar);
            this.panelOTMData.Controls.Add(this.label4);
            this.panelOTMData.Controls.Add(this.zViloyat);
            this.panelOTMData.Controls.Add(this.label3);
            this.panelOTMData.Controls.Add(this.zRasm);
            this.panelOTMData.Controls.Add(this.label2);
            this.panelOTMData.Controls.Add(this.zNom);
            this.panelOTMData.Controls.Add(this.label1);
            this.panelOTMData.Controls.Add(this.zId);
            this.panelOTMData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOTMData.Location = new System.Drawing.Point(0, 28);
            this.panelOTMData.Name = "panelOTMData";
            this.panelOTMData.Size = new System.Drawing.Size(788, 203);
            this.panelOTMData.TabIndex = 6;
            // 
            // zTalim_yonalishlari_ids
            // 
            this.zTalim_yonalishlari_ids.CheckOnClick = true;
            this.zTalim_yonalishlari_ids.Dock = System.Windows.Forms.DockStyle.Top;
            this.zTalim_yonalishlari_ids.FormattingEnabled = true;
            this.zTalim_yonalishlari_ids.HorizontalScrollbar = true;
            this.zTalim_yonalishlari_ids.Location = new System.Drawing.Point(0, 2428);
            this.zTalim_yonalishlari_ids.Name = "zTalim_yonalishlari_ids";
            this.zTalim_yonalishlari_ids.Size = new System.Drawing.Size(763, 91);
            this.zTalim_yonalishlari_ids.Sorted = true;
            this.zTalim_yonalishlari_ids.TabIndex = 81;
            this.zTalim_yonalishlari_ids.ThreeDCheckBoxes = true;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Dock = System.Windows.Forms.DockStyle.Top;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(0, 2402);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(763, 26);
            this.label37.TabIndex = 76;
            this.label37.Text = "Ta\'lim yo\'nalishlari(Mavjud ta\'lim yo\'nalishlar tanlangan holatda)";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zFakultetlar_soni
            // 
            this.zFakultetlar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zFakultetlar_soni.Location = new System.Drawing.Point(0, 2368);
            this.zFakultetlar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zFakultetlar_soni.Name = "zFakultetlar_soni";
            this.zFakultetlar_soni.Size = new System.Drawing.Size(763, 34);
            this.zFakultetlar_soni.TabIndex = 75;
            this.zFakultetlar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Dock = System.Windows.Forms.DockStyle.Top;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(0, 2342);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(763, 26);
            this.label36.TabIndex = 74;
            this.label36.Text = "Fakultetlar soni";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zKontrakt_joylar
            // 
            this.zKontrakt_joylar.Dock = System.Windows.Forms.DockStyle.Top;
            this.zKontrakt_joylar.Location = new System.Drawing.Point(0, 2308);
            this.zKontrakt_joylar.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.zKontrakt_joylar.Name = "zKontrakt_joylar";
            this.zKontrakt_joylar.Size = new System.Drawing.Size(763, 34);
            this.zKontrakt_joylar.TabIndex = 73;
            this.zKontrakt_joylar.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Dock = System.Windows.Forms.DockStyle.Top;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(0, 2282);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(763, 26);
            this.label35.TabIndex = 72;
            this.label35.Text = "Kontrakt asosida o\'qish uchun ajratilgan joylar";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zGrant_joylar
            // 
            this.zGrant_joylar.Dock = System.Windows.Forms.DockStyle.Top;
            this.zGrant_joylar.Location = new System.Drawing.Point(0, 2248);
            this.zGrant_joylar.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.zGrant_joylar.Name = "zGrant_joylar";
            this.zGrant_joylar.Size = new System.Drawing.Size(763, 34);
            this.zGrant_joylar.TabIndex = 71;
            this.zGrant_joylar.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Dock = System.Windows.Forms.DockStyle.Top;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(0, 2222);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(763, 26);
            this.label34.TabIndex = 70;
            this.label34.Text = "Grant asosida o\'qish uchun ajratilgan joylar";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zAjratilgan_joylar
            // 
            this.zAjratilgan_joylar.Dock = System.Windows.Forms.DockStyle.Top;
            this.zAjratilgan_joylar.Location = new System.Drawing.Point(0, 2188);
            this.zAjratilgan_joylar.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.zAjratilgan_joylar.Name = "zAjratilgan_joylar";
            this.zAjratilgan_joylar.Size = new System.Drawing.Size(763, 34);
            this.zAjratilgan_joylar.TabIndex = 69;
            this.zAjratilgan_joylar.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Dock = System.Windows.Forms.DockStyle.Top;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(0, 2162);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(763, 26);
            this.label33.TabIndex = 68;
            this.label33.Text = "Qabul uchun ajratilgan joylar(kvotalar)";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zYotoqxona_tolovi
            // 
            this.zYotoqxona_tolovi.Dock = System.Windows.Forms.DockStyle.Top;
            this.zYotoqxona_tolovi.Location = new System.Drawing.Point(0, 2128);
            this.zYotoqxona_tolovi.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.zYotoqxona_tolovi.Name = "zYotoqxona_tolovi";
            this.zYotoqxona_tolovi.Size = new System.Drawing.Size(763, 34);
            this.zYotoqxona_tolovi.TabIndex = 67;
            this.zYotoqxona_tolovi.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Dock = System.Windows.Forms.DockStyle.Top;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(0, 2102);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(763, 26);
            this.label32.TabIndex = 66;
            this.label32.Text = "Yotoqxona to\'lovi";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zOrtacha_kontrakt_tolovi
            // 
            this.zOrtacha_kontrakt_tolovi.Dock = System.Windows.Forms.DockStyle.Top;
            this.zOrtacha_kontrakt_tolovi.Location = new System.Drawing.Point(0, 2068);
            this.zOrtacha_kontrakt_tolovi.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.zOrtacha_kontrakt_tolovi.Name = "zOrtacha_kontrakt_tolovi";
            this.zOrtacha_kontrakt_tolovi.Size = new System.Drawing.Size(763, 34);
            this.zOrtacha_kontrakt_tolovi.TabIndex = 65;
            this.zOrtacha_kontrakt_tolovi.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Dock = System.Windows.Forms.DockStyle.Top;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(0, 2042);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(763, 26);
            this.label31.TabIndex = 64;
            this.label31.Text = "Kontrakt to\'lovi(o\'rtacha)";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zOrtacha_stipendiya
            // 
            this.zOrtacha_stipendiya.Dock = System.Windows.Forms.DockStyle.Top;
            this.zOrtacha_stipendiya.Location = new System.Drawing.Point(0, 2008);
            this.zOrtacha_stipendiya.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.zOrtacha_stipendiya.Name = "zOrtacha_stipendiya";
            this.zOrtacha_stipendiya.Size = new System.Drawing.Size(763, 34);
            this.zOrtacha_stipendiya.TabIndex = 63;
            this.zOrtacha_stipendiya.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Dock = System.Windows.Forms.DockStyle.Top;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(0, 1982);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(763, 26);
            this.label30.TabIndex = 62;
            this.label30.Text = "Stipendiya(o\'rtacha)";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zYotoqxona_sigimi
            // 
            this.zYotoqxona_sigimi.Dock = System.Windows.Forms.DockStyle.Top;
            this.zYotoqxona_sigimi.Location = new System.Drawing.Point(0, 1948);
            this.zYotoqxona_sigimi.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.zYotoqxona_sigimi.Name = "zYotoqxona_sigimi";
            this.zYotoqxona_sigimi.Size = new System.Drawing.Size(763, 34);
            this.zYotoqxona_sigimi.TabIndex = 61;
            this.zYotoqxona_sigimi.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Dock = System.Windows.Forms.DockStyle.Top;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(0, 1922);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(763, 26);
            this.label29.TabIndex = 60;
            this.label29.Text = "Yotoqxona sig\'imi(necha kishi sig\'a olishi)";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zOquv_bino_sigimi
            // 
            this.zOquv_bino_sigimi.Dock = System.Windows.Forms.DockStyle.Top;
            this.zOquv_bino_sigimi.Location = new System.Drawing.Point(0, 1888);
            this.zOquv_bino_sigimi.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.zOquv_bino_sigimi.Name = "zOquv_bino_sigimi";
            this.zOquv_bino_sigimi.Size = new System.Drawing.Size(763, 34);
            this.zOquv_bino_sigimi.TabIndex = 59;
            this.zOquv_bino_sigimi.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Dock = System.Windows.Forms.DockStyle.Top;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(0, 1862);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(763, 26);
            this.label28.TabIndex = 58;
            this.label28.Text = "Oliy o\'quv yurti binosining sig\'imi(necha kishi sig\'a olishi)";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zAxborot_resurslari_soni
            // 
            this.zAxborot_resurslari_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zAxborot_resurslari_soni.Location = new System.Drawing.Point(0, 1828);
            this.zAxborot_resurslari_soni.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.zAxborot_resurslari_soni.Name = "zAxborot_resurslari_soni";
            this.zAxborot_resurslari_soni.Size = new System.Drawing.Size(763, 34);
            this.zAxborot_resurslari_soni.TabIndex = 57;
            this.zAxborot_resurslari_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Dock = System.Windows.Forms.DockStyle.Top;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(0, 1802);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(763, 26);
            this.label27.TabIndex = 56;
            this.label27.Text = "Axborot resurslari soni";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zOrtacha_GPA
            // 
            this.zOrtacha_GPA.Dock = System.Windows.Forms.DockStyle.Top;
            this.zOrtacha_GPA.Location = new System.Drawing.Point(0, 1768);
            this.zOrtacha_GPA.Name = "zOrtacha_GPA";
            this.zOrtacha_GPA.Size = new System.Drawing.Size(763, 34);
            this.zOrtacha_GPA.TabIndex = 55;
            this.zOrtacha_GPA.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Dock = System.Windows.Forms.DockStyle.Top;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(0, 1742);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(763, 26);
            this.label26.TabIndex = 54;
            this.label26.Text = "Talabalarning o\'rtacha GPA bali";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zUmumiy_qarz
            // 
            this.zUmumiy_qarz.Dock = System.Windows.Forms.DockStyle.Top;
            this.zUmumiy_qarz.Location = new System.Drawing.Point(0, 1708);
            this.zUmumiy_qarz.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.zUmumiy_qarz.Name = "zUmumiy_qarz";
            this.zUmumiy_qarz.Size = new System.Drawing.Size(763, 34);
            this.zUmumiy_qarz.TabIndex = 53;
            this.zUmumiy_qarz.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Dock = System.Windows.Forms.DockStyle.Top;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(0, 1682);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(763, 26);
            this.label25.TabIndex = 52;
            this.label25.Text = "Qarzdor talabalarning umumiy qarzi(so\'m valyutasida)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zQarzdor_talabalar_soni
            // 
            this.zQarzdor_talabalar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zQarzdor_talabalar_soni.Location = new System.Drawing.Point(0, 1648);
            this.zQarzdor_talabalar_soni.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.zQarzdor_talabalar_soni.Name = "zQarzdor_talabalar_soni";
            this.zQarzdor_talabalar_soni.Size = new System.Drawing.Size(763, 34);
            this.zQarzdor_talabalar_soni.TabIndex = 51;
            this.zQarzdor_talabalar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Dock = System.Windows.Forms.DockStyle.Top;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(0, 1622);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(763, 26);
            this.label24.TabIndex = 50;
            this.label24.Text = "Qarzdor talabalar soni";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zIsh_bilan_bandlik
            // 
            this.zIsh_bilan_bandlik.Dock = System.Windows.Forms.DockStyle.Top;
            this.zIsh_bilan_bandlik.Location = new System.Drawing.Point(0, 1588);
            this.zIsh_bilan_bandlik.Name = "zIsh_bilan_bandlik";
            this.zIsh_bilan_bandlik.Size = new System.Drawing.Size(763, 34);
            this.zIsh_bilan_bandlik.TabIndex = 49;
            this.zIsh_bilan_bandlik.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Dock = System.Windows.Forms.DockStyle.Top;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(0, 1562);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(763, 26);
            this.label23.TabIndex = 48;
            this.label23.Text = "Bitirgan talabalarning o\'z sohasida ish bilan bandligi(foiz ko\'rsatkichida)";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zBitiruvchilar_soni
            // 
            this.zBitiruvchilar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zBitiruvchilar_soni.Location = new System.Drawing.Point(0, 1528);
            this.zBitiruvchilar_soni.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.zBitiruvchilar_soni.Name = "zBitiruvchilar_soni";
            this.zBitiruvchilar_soni.Size = new System.Drawing.Size(763, 34);
            this.zBitiruvchilar_soni.TabIndex = 47;
            this.zBitiruvchilar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Dock = System.Windows.Forms.DockStyle.Top;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(0, 1502);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(763, 26);
            this.label22.TabIndex = 46;
            this.label22.Text = "Bitiruvchi talabalar soni";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zXorijiy_talabalar_soni
            // 
            this.zXorijiy_talabalar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zXorijiy_talabalar_soni.Location = new System.Drawing.Point(0, 1468);
            this.zXorijiy_talabalar_soni.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.zXorijiy_talabalar_soni.Name = "zXorijiy_talabalar_soni";
            this.zXorijiy_talabalar_soni.Size = new System.Drawing.Size(763, 34);
            this.zXorijiy_talabalar_soni.TabIndex = 45;
            this.zXorijiy_talabalar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Dock = System.Windows.Forms.DockStyle.Top;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(0, 1442);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(763, 26);
            this.label21.TabIndex = 44;
            this.label21.Text = "Xorijiy davlat fuqarosi bo\'lgan talabalar soni";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zAyol_talabalar_soni
            // 
            this.zAyol_talabalar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zAyol_talabalar_soni.Location = new System.Drawing.Point(0, 1408);
            this.zAyol_talabalar_soni.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.zAyol_talabalar_soni.Name = "zAyol_talabalar_soni";
            this.zAyol_talabalar_soni.Size = new System.Drawing.Size(763, 34);
            this.zAyol_talabalar_soni.TabIndex = 43;
            this.zAyol_talabalar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Dock = System.Windows.Forms.DockStyle.Top;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(0, 1382);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(763, 26);
            this.label20.TabIndex = 42;
            this.label20.Text = "Ayol talabalar soni";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zErkak_talabalar_soni
            // 
            this.zErkak_talabalar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zErkak_talabalar_soni.Location = new System.Drawing.Point(0, 1348);
            this.zErkak_talabalar_soni.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.zErkak_talabalar_soni.Name = "zErkak_talabalar_soni";
            this.zErkak_talabalar_soni.Size = new System.Drawing.Size(763, 34);
            this.zErkak_talabalar_soni.TabIndex = 41;
            this.zErkak_talabalar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Dock = System.Windows.Forms.DockStyle.Top;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(0, 1322);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(763, 26);
            this.label19.TabIndex = 40;
            this.label19.Text = "Erkak talabalar soni";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zTalabalar_soni
            // 
            this.zTalabalar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zTalabalar_soni.Location = new System.Drawing.Point(0, 1288);
            this.zTalabalar_soni.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.zTalabalar_soni.Name = "zTalabalar_soni";
            this.zTalabalar_soni.Size = new System.Drawing.Size(763, 34);
            this.zTalabalar_soni.TabIndex = 39;
            this.zTalabalar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Dock = System.Windows.Forms.DockStyle.Top;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(0, 1262);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(763, 26);
            this.label18.TabIndex = 38;
            this.label18.Text = "Talabalar soni";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zOqituvchilar_KPI
            // 
            this.zOqituvchilar_KPI.Dock = System.Windows.Forms.DockStyle.Top;
            this.zOqituvchilar_KPI.Location = new System.Drawing.Point(0, 1228);
            this.zOqituvchilar_KPI.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zOqituvchilar_KPI.Name = "zOqituvchilar_KPI";
            this.zOqituvchilar_KPI.Size = new System.Drawing.Size(763, 34);
            this.zOqituvchilar_KPI.TabIndex = 37;
            this.zOqituvchilar_KPI.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(0, 1202);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(763, 26);
            this.label17.TabIndex = 36;
            this.label17.Text = "Professor-oʻqituvchilarning o\'rtacha KPI bali";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zTadqiqot_mablaglari
            // 
            this.zTadqiqot_mablaglari.Dock = System.Windows.Forms.DockStyle.Top;
            this.zTadqiqot_mablaglari.Location = new System.Drawing.Point(0, 1168);
            this.zTadqiqot_mablaglari.Maximum = new decimal(new int[] {
            1410065408,
            2,
            0,
            0});
            this.zTadqiqot_mablaglari.Name = "zTadqiqot_mablaglari";
            this.zTadqiqot_mablaglari.Size = new System.Drawing.Size(763, 34);
            this.zTadqiqot_mablaglari.TabIndex = 80;
            this.zTadqiqot_mablaglari.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Dock = System.Windows.Forms.DockStyle.Top;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(0, 1142);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(763, 26);
            this.label38.TabIndex = 79;
            this.label38.Text = "Ilmiy tadqiqot natijalari asosida olingan mablag\'lari ko\'rsatkichi";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zIlmiy_iqtiboslar_soni
            // 
            this.zIlmiy_iqtiboslar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zIlmiy_iqtiboslar_soni.Location = new System.Drawing.Point(0, 1108);
            this.zIlmiy_iqtiboslar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zIlmiy_iqtiboslar_soni.Name = "zIlmiy_iqtiboslar_soni";
            this.zIlmiy_iqtiboslar_soni.Size = new System.Drawing.Size(763, 34);
            this.zIlmiy_iqtiboslar_soni.TabIndex = 35;
            this.zIlmiy_iqtiboslar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(0, 1082);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(763, 26);
            this.label16.TabIndex = 34;
            this.label16.Text = "Ilmiy maqolalariga iqtiboslar soni(Xalqaro Scopus va Web of Science ma\'lumotlar b" +
    "azasidagi)";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zIlmiy_maqolalar_soni
            // 
            this.zIlmiy_maqolalar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zIlmiy_maqolalar_soni.Location = new System.Drawing.Point(0, 1048);
            this.zIlmiy_maqolalar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zIlmiy_maqolalar_soni.Name = "zIlmiy_maqolalar_soni";
            this.zIlmiy_maqolalar_soni.Size = new System.Drawing.Size(763, 34);
            this.zIlmiy_maqolalar_soni.TabIndex = 33;
            this.zIlmiy_maqolalar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Dock = System.Windows.Forms.DockStyle.Top;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(0, 1022);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(763, 26);
            this.label15.TabIndex = 32;
            this.label15.Text = "Ilmiy maqolalar soni(Xalqaro Scopus va Web of Science ma\'lumotlar bazasidagi)";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zXorijiy_oqituvchilar_soni
            // 
            this.zXorijiy_oqituvchilar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zXorijiy_oqituvchilar_soni.Location = new System.Drawing.Point(0, 988);
            this.zXorijiy_oqituvchilar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zXorijiy_oqituvchilar_soni.Name = "zXorijiy_oqituvchilar_soni";
            this.zXorijiy_oqituvchilar_soni.Size = new System.Drawing.Size(763, 34);
            this.zXorijiy_oqituvchilar_soni.TabIndex = 31;
            this.zXorijiy_oqituvchilar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Dock = System.Windows.Forms.DockStyle.Top;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(0, 962);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(763, 26);
            this.label14.TabIndex = 30;
            this.label14.Text = "Xorijiy davlat professor-o\'qituvchilar soni";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zAkademiklar_soni
            // 
            this.zAkademiklar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zAkademiklar_soni.Location = new System.Drawing.Point(0, 928);
            this.zAkademiklar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zAkademiklar_soni.Name = "zAkademiklar_soni";
            this.zAkademiklar_soni.Size = new System.Drawing.Size(763, 34);
            this.zAkademiklar_soni.TabIndex = 29;
            this.zAkademiklar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Dock = System.Windows.Forms.DockStyle.Top;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(0, 902);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(763, 26);
            this.label13.TabIndex = 28;
            this.label13.Text = "Akademiklar soni";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zProfessorlar_soni
            // 
            this.zProfessorlar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zProfessorlar_soni.Location = new System.Drawing.Point(0, 868);
            this.zProfessorlar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zProfessorlar_soni.Name = "zProfessorlar_soni";
            this.zProfessorlar_soni.Size = new System.Drawing.Size(763, 34);
            this.zProfessorlar_soni.TabIndex = 27;
            this.zProfessorlar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(0, 842);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(763, 26);
            this.label12.TabIndex = 26;
            this.label12.Text = "Professorlar soni";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zDontsentlar_soni
            // 
            this.zDontsentlar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zDontsentlar_soni.Location = new System.Drawing.Point(0, 808);
            this.zDontsentlar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zDontsentlar_soni.Name = "zDontsentlar_soni";
            this.zDontsentlar_soni.Size = new System.Drawing.Size(763, 34);
            this.zDontsentlar_soni.TabIndex = 25;
            this.zDontsentlar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Dock = System.Windows.Forms.DockStyle.Top;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(0, 782);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(763, 26);
            this.label11.TabIndex = 24;
            this.label11.Text = "Dotsentlar soni";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zOqituvchilar_soni
            // 
            this.zOqituvchilar_soni.Dock = System.Windows.Forms.DockStyle.Top;
            this.zOqituvchilar_soni.Location = new System.Drawing.Point(0, 748);
            this.zOqituvchilar_soni.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.zOqituvchilar_soni.Name = "zOqituvchilar_soni";
            this.zOqituvchilar_soni.Size = new System.Drawing.Size(763, 34);
            this.zOqituvchilar_soni.TabIndex = 23;
            this.zOqituvchilar_soni.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Dock = System.Windows.Forms.DockStyle.Top;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(0, 722);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(763, 26);
            this.label10.TabIndex = 22;
            this.label10.Text = "O\'qituvchilar soni";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zVeb_sayti
            // 
            this.zVeb_sayti.BackColor = System.Drawing.Color.White;
            this.zVeb_sayti.Dock = System.Windows.Forms.DockStyle.Top;
            this.zVeb_sayti.Location = new System.Drawing.Point(0, 688);
            this.zVeb_sayti.Name = "zVeb_sayti";
            this.zVeb_sayti.Size = new System.Drawing.Size(763, 34);
            this.zVeb_sayti.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(0, 662);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(763, 26);
            this.label9.TabIndex = 20;
            this.label9.Text = "Veb sayti";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zEmail
            // 
            this.zEmail.BackColor = System.Drawing.Color.White;
            this.zEmail.Dock = System.Windows.Forms.DockStyle.Top;
            this.zEmail.Location = new System.Drawing.Point(0, 628);
            this.zEmail.Name = "zEmail";
            this.zEmail.Size = new System.Drawing.Size(763, 34);
            this.zEmail.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(0, 602);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(763, 26);
            this.label8.TabIndex = 18;
            this.label8.Text = "Email";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zTelefon
            // 
            this.zTelefon.BackColor = System.Drawing.Color.White;
            this.zTelefon.Dock = System.Windows.Forms.DockStyle.Top;
            this.zTelefon.Location = new System.Drawing.Point(0, 568);
            this.zTelefon.Name = "zTelefon";
            this.zTelefon.Size = new System.Drawing.Size(763, 34);
            this.zTelefon.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(0, 542);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(763, 26);
            this.label7.TabIndex = 16;
            this.label7.Text = "Telefon raqam";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zTashkil_etilgan_yili
            // 
            this.zTashkil_etilgan_yili.Dock = System.Windows.Forms.DockStyle.Top;
            this.zTashkil_etilgan_yili.Location = new System.Drawing.Point(0, 508);
            this.zTashkil_etilgan_yili.Maximum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.zTashkil_etilgan_yili.Minimum = new decimal(new int[] {
            1800,
            0,
            0,
            0});
            this.zTashkil_etilgan_yili.Name = "zTashkil_etilgan_yili";
            this.zTashkil_etilgan_yili.Size = new System.Drawing.Size(763, 34);
            this.zTashkil_etilgan_yili.TabIndex = 15;
            this.zTashkil_etilgan_yili.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.zTashkil_etilgan_yili.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Dock = System.Windows.Forms.DockStyle.Top;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(0, 482);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(763, 26);
            this.label6.TabIndex = 14;
            this.label6.Text = "Tashkil etilgan yili";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zHolat
            // 
            this.zHolat.Dock = System.Windows.Forms.DockStyle.Top;
            this.zHolat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.zHolat.FormattingEnabled = true;
            this.zHolat.Items.AddRange(new object[] {
            "Davlat",
            "Nodavlat",
            "Xorijiy"});
            this.zHolat.Location = new System.Drawing.Point(0, 445);
            this.zHolat.Name = "zHolat";
            this.zHolat.Size = new System.Drawing.Size(763, 37);
            this.zHolat.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(0, 419);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(763, 26);
            this.label5.TabIndex = 12;
            this.label5.Text = "Holat(Davlat, Nodavlat yoki Xorijiy)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zShahar
            // 
            this.zShahar.BackColor = System.Drawing.Color.White;
            this.zShahar.Dock = System.Windows.Forms.DockStyle.Top;
            this.zShahar.Location = new System.Drawing.Point(0, 385);
            this.zShahar.Name = "zShahar";
            this.zShahar.Size = new System.Drawing.Size(763, 34);
            this.zShahar.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(0, 359);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(763, 26);
            this.label4.TabIndex = 10;
            this.label4.Text = "Manzil (Shahar yoki tuman, ko\'cha va uy(bino))";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zViloyat
            // 
            this.zViloyat.Dock = System.Windows.Forms.DockStyle.Top;
            this.zViloyat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.zViloyat.FormattingEnabled = true;
            this.zViloyat.Items.AddRange(new object[] {
            "Andijon viloyati",
            "Buxoro viloyati",
            "Fargʻona viloyati",
            "Jizzax viloyati",
            "Namangan viloyati",
            "Navoiy viloyati",
            "Qashqadaryo viloyati",
            "Qoraqalpogʻiston Respublikasi",
            "Samarqand viloyati",
            "Sirdaryo viloyati",
            "Surxondaryo viloyati",
            "Toshkent viloyati",
            "Xorazm viloyati"});
            this.zViloyat.Location = new System.Drawing.Point(0, 322);
            this.zViloyat.Name = "zViloyat";
            this.zViloyat.Size = new System.Drawing.Size(763, 37);
            this.zViloyat.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(0, 296);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(763, 26);
            this.label3.TabIndex = 7;
            this.label3.Text = "Viloyat";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(0, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(763, 26);
            this.label2.TabIndex = 5;
            this.label2.Text = "Rasm(kiritish uchun ikki marta bosing)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // zNom
            // 
            this.zNom.BackColor = System.Drawing.Color.White;
            this.zNom.Dock = System.Windows.Forms.DockStyle.Top;
            this.zNom.Location = new System.Drawing.Point(0, 52);
            this.zNom.Name = "zNom";
            this.zNom.Size = new System.Drawing.Size(763, 34);
            this.zNom.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(763, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nom";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(788, 28);
            this.menuStrip2.TabIndex = 2;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Image = global::Universitetlarni_taqqoslash.Properties.Resources.add;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(98, 24);
            this.toolStripMenuItem5.Text = "Qo\'shish";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Image = global::Universitetlarni_taqqoslash.Properties.Resources.rubber;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(100, 24);
            this.toolStripMenuItem6.Text = "Tozalash";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Image = global::Universitetlarni_taqqoslash.Properties.Resources.upgrade;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(105, 24);
            this.toolStripMenuItem7.Text = "Yangilash";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Image = global::Universitetlarni_taqqoslash.Properties.Resources.delete;
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(99, 24);
            this.toolStripMenuItem8.Text = "O\'chirish";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // Sozlamalar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Universitetlarni_taqqoslash.Properties.Resources.database;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1088, 567);
            this.Controls.Add(this.panelOTMedit);
            this.Controls.Add(this.panelYonalishlar);
            this.Controls.Add(this.flowLayoutPanelOTMlar);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "Sozlamalar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sozlamalar";
            this.Load += new System.EventHandler(this.Sozlamalar_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelYonalishlar.ResumeLayout(false);
            this.panelYonalishlar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewYonalish)).EndInit();
            this.menuStrip3.ResumeLayout(false);
            this.menuStrip3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zRasm)).EndInit();
            this.panelOTMedit.ResumeLayout(false);
            this.panelOTMedit.PerformLayout();
            this.panelOTMData.ResumeLayout(false);
            this.panelOTMData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zFakultetlar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zKontrakt_joylar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zGrant_joylar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAjratilgan_joylar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zYotoqxona_tolovi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOrtacha_kontrakt_tolovi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOrtacha_stipendiya)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zYotoqxona_sigimi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOquv_bino_sigimi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAxborot_resurslari_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOrtacha_GPA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zUmumiy_qarz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zQarzdor_talabalar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zIsh_bilan_bandlik)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zBitiruvchilar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zXorijiy_talabalar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAyol_talabalar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zErkak_talabalar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zTalabalar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOqituvchilar_KPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zTadqiqot_mablaglari)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zIlmiy_iqtiboslar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zIlmiy_maqolalar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zXorijiy_oqituvchilar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zAkademiklar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zProfessorlar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zDontsentlar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zOqituvchilar_soni)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zTashkil_etilgan_yili)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem malumotlarBazasiBilanBoglashToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiqishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yangiMalumotlarBazasiYaratishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem malumotlarBazasiJoylashuviniKorishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parolniAlmashtirishToolStripMenuItem;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelOTMlar;
        private System.Windows.Forms.Panel panelYonalishlar;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.DataGridView dataGridViewYonalish;
        private System.Windows.Forms.TextBox textBoxYonalish;
        private System.Windows.Forms.Label labelYonalishID;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panelOTMedit;
        private System.Windows.Forms.Panel panelOTMData;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown zFakultetlar_soni;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.NumericUpDown zKontrakt_joylar;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown zGrant_joylar;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown zAjratilgan_joylar;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown zYotoqxona_tolovi;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown zOrtacha_kontrakt_tolovi;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown zOrtacha_stipendiya;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown zYotoqxona_sigimi;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown zOquv_bino_sigimi;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown zAxborot_resurslari_soni;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown zOrtacha_GPA;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown zUmumiy_qarz;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown zQarzdor_talabalar_soni;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown zIsh_bilan_bandlik;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown zBitiruvchilar_soni;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown zXorijiy_talabalar_soni;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown zAyol_talabalar_soni;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown zErkak_talabalar_soni;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown zTalabalar_soni;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown zOqituvchilar_KPI;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown zIlmiy_iqtiboslar_soni;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown zIlmiy_maqolalar_soni;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown zXorijiy_oqituvchilar_soni;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown zAkademiklar_soni;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown zProfessorlar_soni;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown zDontsentlar_soni;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown zOqituvchilar_soni;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox zVeb_sayti;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox zEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox zTelefon;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown zTashkil_etilgan_yili;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox zHolat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox zShahar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox zViloyat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox zRasm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox zNom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label zId;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.NumericUpDown zTadqiqot_mablaglari;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.CheckedListBox zTalim_yonalishlari_ids;
    }
}